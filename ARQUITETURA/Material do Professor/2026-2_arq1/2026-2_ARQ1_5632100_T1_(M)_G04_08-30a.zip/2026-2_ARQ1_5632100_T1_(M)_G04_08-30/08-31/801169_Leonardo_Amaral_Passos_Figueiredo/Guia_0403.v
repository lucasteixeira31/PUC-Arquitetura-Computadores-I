/*
 Guia_0403d.v
 801169 - Leonardo Amaral
*/

module Guia_0403(
    output s,
    input x,
    input y,
    input w,
    input z
);

assign s =
    (~x & ~y & ~w & ~z) |
    (~x & ~y & w & ~z)  |
    (~x & y & ~w & ~z)  |
    (~x & y & w & ~z)   |
    (x & y & ~w & ~z)   |
    (x & y & ~w & z)    |
    (x & y & w & ~z);

endmodule