/*
 Guia_0404c.v
 801169 - Leonardo Amaral
*/

module Guia_0404(
    output F,
    input X,
    input Y,
    input W,
    input Z
);

assign F =
    (X | Y | W | Z) &
    (X | Y | W | ~Z) &
    (X | Y | ~W | Z) &
    (X | ~Y | ~W | Z) &
    (X | ~Y | ~W | ~Z) &
    (~X | Y | W | Z) &
    (~X | Y | ~W | ~Z) &
    (~X | ~Y | W | ~Z);

endmodule