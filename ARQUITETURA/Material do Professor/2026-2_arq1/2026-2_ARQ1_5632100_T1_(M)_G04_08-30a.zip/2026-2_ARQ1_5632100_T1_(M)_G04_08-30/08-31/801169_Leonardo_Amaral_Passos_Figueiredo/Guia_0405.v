/*
 Guia_0405b.v
 801169 - Leonardo Amaral
*/
module Guia_0505(
    output f,
    input x,
    input y
);

assign f = (~x & ~y) | (x & ~y) | (x & y);

endmodule