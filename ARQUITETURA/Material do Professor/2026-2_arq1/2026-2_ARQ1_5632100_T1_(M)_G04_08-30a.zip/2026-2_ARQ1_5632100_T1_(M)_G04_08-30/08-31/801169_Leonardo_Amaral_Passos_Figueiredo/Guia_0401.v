
/*
 Guia_0401.v
 801169 - Leonardo Amaral
*/

module Guia_0401(
    output s,
    input x,
    input y,
    input z
);

assign s = x & ~(y | ~z);

endmodule

/*
 Guia_0401b.v
 801169 - Leonardo Amaral
*/

module Guia_0401b(
    output s,
    input x,
    input y,
    input z
);

assign s = ~(x | ~y) & z;

endmodule

/*
 Guia_0401c.v
 801169 - Leonardo Amaral
*/

module Guia_0401c(
    output s,
    input x,
    input y,
    input z
);

assign s = ~(~x & y) & ~z;

endmodule

/*
 Guia_0401d.v
 801169 - Leonardo Amaral
*/

module Guia_0401d(
    output s,
    input x,
    input y,
    input z
);

assign s = ~(~x & y) & z;

endmodule

/*
 Guia_0401e.v
 801169 - Leonardo Amaral
*/

module Guia_0401e(
    output s,
    input x,
    input y,
    input z
);

assign s = (~x | ~y) & ~(y | ~z);

endmodule
````