/*
 Guia_0402e.v
 801169 - Leonardo Amaral
*/

module Guia_0402(
    output s,
    input x,
    input y,
    input z
);

assign s = (y | ~x | ~z) & ~(~y | x | z);

endmodule