/*
Guia_0401.v
678019 - Rafael Cortat De Oliveira
*/

// a.) x . (y + z')'
module funcA (output s, input x, input y, input z);
    assign s = x & ~(y | ~z);
endmodule

// b.) (x + y')' . z
module funcB (output s, input x, input y, input z);
    assign s = ~(x | ~y) & z;
endmodule

// c.) (x' . y)' . z'
module funcC (output s, input x, input y, input z);
    assign s = ~(~x & y) & ~z;
endmodule

// d.) (x' . y)' . z
module funcD (output s, input x, input y, input z);
    assign s = ~(~x & y) & z;
endmodule

// e.) (x' + y') . (y + z')'
module funcE (output s, input x, input y, input z);
    assign s = (~x | ~y) & ~(y | ~z); 
endmodule

module Guia_0401;
    reg x, y, z;
    wire sA, sB, sC, sD, sE;

    // instancias
    funcA FA (sA, x, y, z);
    funcB FB (sB, x, y, z);
    funcC FC (sC, x, y, z);
    funcD FD (sD, x, y, z);
    funcE FE (sE, x, y, z);

    // valores iniciais
    initial begin: start
        x=1'bx; y=1'bx; z=1'bx; // indefinidos
    end

    // parte principal
    initial begin: main
        // identificacao
        $display("Guia_0401 - Rafael Cortat De Oliveira - 678019");
        $display("Test Boolean Expressions");
        
        // monitoramento
        $display("\n x y z | funcA | funcB | funcC | funcD | funcE ");
        $display("-------+-------+-------+-------+-------+-------");
        $monitor(" %b %b %b |   %b   |   %b   |   %b   |   %b   |   %b   ", x, y, z, sA, sB, sC, sD, sE);

        // sinalizacao
        #1 x=0; y=0; z=0;
        #1 x=0; y=0; z=1;
        #1 x=0; y=1; z=0;
        #1 x=0; y=1; z=1;
        #1 x=1; y=0; z=0;
        #1 x=1; y=0; z=1;
        #1 x=1; y=1; z=0;
        #1 x=1; y=1; z=1;
    end
endmodule // Guia_0401
