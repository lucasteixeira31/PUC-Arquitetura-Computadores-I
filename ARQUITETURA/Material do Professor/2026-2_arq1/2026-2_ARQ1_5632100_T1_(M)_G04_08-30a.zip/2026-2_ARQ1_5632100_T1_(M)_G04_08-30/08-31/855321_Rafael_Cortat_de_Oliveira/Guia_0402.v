/*
Guia_0402.v
678019 - Rafael Cortat De Oliveira
*/

// a.) x . ( x' + y )' = x . y'
module funcA (output s_orig, output s_simp, input x, input y, input z);
    assign s_orig = x & ~(~x | y);
    assign s_simp = x & ~y;
endmodule

// b.) ( x' + y' ) + ( x . y ) = 1
module funcB (output s_orig, output s_simp, input x, input y, input z);
    assign s_orig = (~x | ~y) | (x & y);
    assign s_simp = 1'b1;
endmodule

// c.) ( x . y )' . ( x + y' ) = y'
module funcC (output s_orig, output s_simp, input x, input y, input z);
    assign s_orig = ~(x & y) & (x | ~y);
    assign s_simp = ~y;
endmodule

// d.) ( x' . y )' + ( x + y' )' = 1
module funcD (output s_orig, output s_simp, input x, input y, input z);
    assign s_orig = ~(~x & y) | ~(x | ~y);
    assign s_simp = 1'b1;
endmodule

// e.) ( y + x' + z' ) . ( y' + x + z )' = x' . y . z'
module funcE (output s_orig, output s_simp, input x, input y, input z);
    assign s_orig = (y | ~x | ~z) & ~(~y | x | z); 
    assign s_simp = ~x & y & ~z; 
endmodule

module Guia_0402;
    reg x, y, z;
    wire a_orig, a_simp;
    wire b_orig, b_simp;
    wire c_orig, c_simp;
    wire d_orig, d_simp;
    wire e_orig, e_simp;

    // instancias
    funcA FA (a_orig, a_simp, x, y, z);
    funcB FB (b_orig, b_simp, x, y, z);
    funcC FC (c_orig, c_simp, x, y, z);
    funcD FD (d_orig, d_simp, x, y, z);
    funcE FE (e_orig, e_simp, x, y, z);

    // valores iniciais
    initial begin: start
        x=1'bx; y=1'bx; z=1'bx; // indefinidos
    end

    // parte principal
    initial begin: main
        // identificacao
        $display("Guia_0402 - Rafael Cortat De Oliveira - 678019");
        $display("Test Boolean Expressions vs Simplifications");
        
        // monitoramento
        $display("\n x y z | funcA (o/s) | funcB (o/s) | funcC (o/s) | funcD (o/s) | funcE (o/s) ");
        $display("-------+-------------+-------------+-------------+-------------+-------------");
        $monitor(" %b %b %b |    %b / %b    |    %b / %b    |    %b / %b    |    %b / %b    |    %b / %b    ", 
                 x, y, z, 
                 a_orig, a_simp, 
                 b_orig, b_simp, 
                 c_orig, c_simp, 
                 d_orig, d_simp, 
                 e_orig, e_simp);

        // sinalizacao
        #1 x=0; y=0; z=0;
        #1 x=0; y=0; z=1;
        #1 x=0; y=1; z=0;
        #1 x=0; y=1; z=1;
        #1 x=1; y=0; z=0;
        #1 x=1; y=0; z=1;
        #1 x=1; y=1; z=0;
        #1 x=1; y=1; z=1;
    end
endmodule // Guia_0402