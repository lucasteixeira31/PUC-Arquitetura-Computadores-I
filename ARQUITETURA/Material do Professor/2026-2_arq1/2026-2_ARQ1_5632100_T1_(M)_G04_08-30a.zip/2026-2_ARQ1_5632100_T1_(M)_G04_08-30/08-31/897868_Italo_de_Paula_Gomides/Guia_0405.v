// ---------------------
// GUIA 04 - QUESTAO 05
// Nome: xxx yyy zzz
// Matricula: 999999
// ---------------------
// Cada modulo implementa a SoP identificada a partir da tabela do PDF.

// a) x y f: 00->0 01->1 10->0 11->1   => f = x'.y + x.y  (= y)
module ex05a (output s, input x, y);
  assign s = (~x&y) | (x&y);
endmodule // ex05a

// b) x y f: 00->1 01->0 10->1 11->1   => f = x'.y' + x.y' + x.y
module ex05b (output s, input x, y);
  assign s = (~x&~y) | (x&~y) | (x&y);
endmodule // ex05b

// c) x y z f: 1,1,1,0,0,0,1,1   => SoP(0,1,2,6,7)
module ex05c (output s, input x, y, z);
  assign s = (~x&~y&~z) | (~x&~y&z) | (~x&y&~z) | (x&y&~z) | (x&y&z);
endmodule // ex05c

// d) x y z f: 1,0,1,0,1,0,1,0   => SoP(0,2,4,6)  (= z')
module ex05d (output s, input x, y, z);
  assign s = (~x&~y&~z) | (~x&y&~z) | (x&~y&~z) | (x&y&~z);
endmodule // ex05d

// e) x y w z f (16 linhas)   => SoP(0,1,4,5,6,10,11,12,15)
module ex05e (output s, input x, y, w, z);
  assign s = (~x&~y&~w&~z) | (~x&~y&~w&z) | (~x&y&~w&~z) | (~x&y&~w&z)
           | (~x&y&w&~z)   | (x&~y&w&~z)  | (x&~y&w&z)   | (x&y&~w&~z)
           | (x&y&w&z);
endmodule // ex05e

// ---------------------
// -- test_module
// ---------------------
module test_module;
  reg x, y, w, z;
  wire sa, sb, sc, sd, se;

  ex05a A (sa, x, y);
  ex05b B (sb, x, y);
  ex05c C (sc, x, y, z);
  ex05d D (sd, x, y, z);
  ex05e E (se, x, y, w, z);

  integer i;

  initial begin: start
    x=1'bx; y=1'bx; w=1'bx; z=1'bx;
  end

  initial begin: main
    $display("Guia_04 - Questao 05 - xxx yyy zzz - 999999");
    $display("x y w z = a b c d e  (varre as 16 combinacoes)");
    $monitor("%b %b %b %b = %b %b %b %b %b", x, y, w, z, sa, sb, sc, sd, se);
    for (i = 0; i < 16; i = i + 1) begin
      #1 {x, y, w, z} = i[3:0];
    end
  end
endmodule // test_module
