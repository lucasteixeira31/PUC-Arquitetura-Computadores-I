// ---------------------
// GUIA 04 - QUESTAO 03
// Nome: xxx yyy zzz
// Matricula: 999999
// ---------------------
// Cada modulo implementa a soma de produtos (SoP) direto dos mintermos dados.

// a) f(x,y,z) = soma m(1,3,4,7)
module ex03a (output s, input x, y, z);
  // m  1        3        4        7
  assign s = (~x&~y&z) | (~x&y&z) | (x&~y&~z) | (x&y&z);
endmodule // ex03a

// b) f(x,y,z) = soma m(2,3,5,6)
module ex03b (output s, input x, y, z);
  // m  2        3        5        6
  assign s = (~x&y&~z) | (~x&y&z) | (x&~y&z) | (x&y&~z);
endmodule // ex03b

// c) f(x,y,w,z) = soma m(1,2,4,6,7,13,15)
module ex03c (output s, input x, y, w, z);
  // m   1            2            4            6
  assign s = (~x&~y&~w&z) | (~x&~y&w&~z) | (~x&y&~w&~z) | (~x&y&w&~z)
  //          7            13           15
            | (~x&y&w&z)  | (x&y&~w&z)  | (x&y&w&z);
endmodule // ex03c

// d) f(x,y,w,z) = soma m(0,2,4,6,12,13,14)
module ex03d (output s, input x, y, w, z);
  // m   0             2             4             6
  assign s = (~x&~y&~w&~z) | (~x&~y&w&~z) | (~x&y&~w&~z) | (~x&y&w&~z)
  //          12            13            14
            | (x&y&~w&~z)  | (x&y&~w&z)  | (x&y&w&~z);
endmodule // ex03d

// e) f(x,y,w,z) = soma m(0,1,8,9,12,15)
module ex03e (output s, input x, y, w, z);
  // m   0             1             8             9
  assign s = (~x&~y&~w&~z) | (~x&~y&~w&z) | (x&~y&~w&~z) | (x&~y&~w&z)
  //          12            15
            | (x&y&~w&~z)  | (x&y&w&z);
endmodule // ex03e

// ---------------------
// -- test_module
// ---------------------
module test_module;
  reg x, y, w, z;
  wire sa, sb, sc, sd, se;

  ex03a A (sa, x, y, z);
  ex03b B (sb, x, y, z);
  ex03c C (sc, x, y, w, z);
  ex03d D (sd, x, y, w, z);
  ex03e E (se, x, y, w, z);

  integer i;

  initial begin: start
    x=1'bx; y=1'bx; w=1'bx; z=1'bx;
  end

  initial begin: main
    $display("Guia_04 - Questao 03 - xxx yyy zzz - 999999");
    $display("x y w z = a b c d e  (varre as 16 combinacoes)");
    $monitor("%b %b %b %b = %b %b %b %b %b", x, y, w, z, sa, sb, sc, sd, se);
    for (i = 0; i < 16; i = i + 1) begin
      #1 {x, y, w, z} = i[3:0];
    end
  end
endmodule // test_module
