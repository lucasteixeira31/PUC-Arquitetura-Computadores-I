// ---------------------
// GUIA 04 - EXTRA 07
// Nome: xxx yyy zzz
// Matricula: 999999
// ---------------------
// Modulo original dado no guia (corrigido o nome de saida para s1, que no
// PDF estava com um pequeno erro de maiuscula/minuscula em "assign s1").
module fxyz (output s1, input x, input y, input z);
  assign s1 = ( x & y & ~z ) | ~( ~x & ~y & ~z );
endmodule // fxyz

// Simplificado: (x.y.z') | (x+y+z) = x+y+z  (absorcao)
module fxyz_simp (output s, input x, y, z);
  assign s = x | y | z;
endmodule // fxyz_simp

// PoS equivalente encontrada: produto M(0)
module fxyz_pos (output s, input x, y, z);
  assign s = (x | y | z);
endmodule // fxyz_pos

// ---------------------
// -- test_module
// ---------------------
module test_module;
  reg x, y, z;
  wire s_orig, s_simp, s_pos;

  fxyz ORIG (s_orig, x, y, z);
  fxyz_simp SIMP (s_simp, x, y, z);
  fxyz_pos POS1 (s_pos, x, y, z);

  initial begin: start
    x=1'bx; y=1'bx; z=1'bx;
  end

  initial begin: main
    $display("Guia_04 - Extra 07 - xxx yyy zzz - 999999");
    $display("As 3 colunas devem ser sempre iguais: orig, x+y+z, PoS");
    $display("x y z = orig simp pos");
    $monitor("%b %b %b = %b    %b    %b", x, y, z, s_orig, s_simp, s_pos);
    #1 x=0; y=0; z=0;
    #1 x=0; y=0; z=1;
    #1 x=0; y=1; z=0;
    #1 x=0; y=1; z=1;
    #1 x=1; y=0; z=0;
    #1 x=1; y=0; z=1;
    #1 x=1; y=1; z=0;
    #1 x=1; y=1; z=1;
  end
endmodule // test_module
