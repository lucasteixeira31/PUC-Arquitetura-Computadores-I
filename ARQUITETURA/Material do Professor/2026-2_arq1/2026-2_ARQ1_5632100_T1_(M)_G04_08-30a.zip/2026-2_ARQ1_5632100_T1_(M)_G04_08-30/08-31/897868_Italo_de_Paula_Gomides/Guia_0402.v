// ---------------------
// GUIA 04 - QUESTAO 02
// Nome: xxx yyy zzz
// Matricula: 999999
// ---------------------
// Cada modulo tem s1 = expressao original e s2 = expressao simplificada.
// Se a simplificacao estiver certa, s1 e s2 tem que dar sempre igual.

// a) x . ( x' + y )'  =  x . y'
module ex02a (output s1, output s2, input x, y);
  assign s1 = x & ~(~x | y);
  assign s2 = x & ~y;
endmodule // ex02a

// b) ( x' + y' ) + ( x . y )  =  1  (tautologia)
module ex02b (output s1, output s2, input x, y);
  assign s1 = (~x | ~y) | (x & y);
  assign s2 = 1'b1;
endmodule // ex02b

// c) ( x . y )' . ( x + y' )  =  y'
module ex02c (output s1, output s2, input x, y);
  assign s1 = ~(x & y) & (x | ~y);
  assign s2 = ~y;
endmodule // ex02c

// d) ( x' . y )' + ( x + y' )'  =  1  (tautologia)
module ex02d (output s1, output s2, input x, y);
  assign s1 = ~(~x & y) | ~(x | ~y);
  assign s2 = 1'b1;
endmodule // ex02d

// e) ( y + x' + z' ) . ( y' + x + z )'  =  x' . y . z'
module ex02e (output s1, output s2, input x, y, z);
  assign s1 = (y | ~x | ~z) & ~(~y | x | z);
  assign s2 = ~x & y & ~z;
endmodule // ex02e

// ---------------------
// -- test_module
// ---------------------
module test_module;
  reg x, y, z;
  wire a1, a2, b1, b2, c1, c2, d1, d2, e1, e2;

  ex02a A (a1, a2, x, y);
  ex02b B (b1, b2, x, y);
  ex02c C (c1, c2, x, y);
  ex02d D (d1, d2, x, y);
  ex02e E (e1, e2, x, y, z);

  initial begin: start
    x = 1'bx; y = 1'bx; z = 1'bx;
  end

  initial begin: main
    $display("Guia_04 - Questao 02 - xxx yyy zzz - 999999");
    $display("Cada par (orig,simp) deve ser sempre igual");
    $display("x y z = a1 a2 | b1 b2 | c1 c2 | d1 d2 | e1 e2");
    $monitor("%b %b %b = %b %b | %b %b | %b %b | %b %b | %b %b",
             x, y, z, a1, a2, b1, b2, c1, c2, d1, d2, e1, e2);
    #1 x=0; y=0; z=0;
    #1 x=0; y=0; z=1;
    #1 x=0; y=1; z=0;
    #1 x=0; y=1; z=1;
    #1 x=1; y=0; z=0;
    #1 x=1; y=0; z=1;
    #1 x=1; y=1; z=0;
    #1 x=1; y=1; z=1;
  end
endmodule // test_module
