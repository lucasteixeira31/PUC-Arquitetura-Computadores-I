// ---------------------
// GUIA 04 - QUESTAO 04
// Nome: xxx yyy zzz
// Matricula: 999999
// ---------------------
// Cada modulo implementa o produto de somas (PoS) direto dos maxtermos dados.

// a) F(X,Y,Z) = produto M(1,2,4,6)
module ex04a (output s, input x, y, z);
  // M   1          2          4          6
  assign s = (x|y|~z) & (x|~y|z) & (~x|y|z) & (~x|~y|z);
endmodule // ex04a

// b) F(X,Y,Z) = produto M(0,2,3,7)
module ex04b (output s, input x, y, z);
  // M   0        2          3           7
  assign s = (x|y|z) & (x|~y|z) & (x|~y|~z) & (~x|~y|~z);
endmodule // ex04b

// c) F(X,Y,W,Z) = produto M(0,1,2,6,7,8,11,13)
module ex04c (output s, input x, y, w, z);
  // M   0              1              2
  assign s = (x|y|w|z) & (x|y|w|~z) & (x|y|~w|z)
  //          6               7                8
            & (x|~y|~w|z) & (x|~y|~w|~z) & (~x|y|w|z)
  //          11                13
            & (~x|y|~w|~z) & (~x|~y|w|~z);
endmodule // ex04c

// d) F(X,Y,W,Z) = produto M(1,2,4,6,8,12,14)
module ex04d (output s, input x, y, w, z);
  // M   1              2              4
  assign s = (x|y|w|~z) & (x|y|~w|z) & (x|~y|w|z)
  //          6              8               12
            & (x|~y|~w|z) & (~x|y|w|z) & (~x|~y|w|z)
  //          14
            & (~x|~y|~w|z);
endmodule // ex04d

// e) F(X,Y,W,Z) = produto M(0,1,2,4,7,12,15)
module ex04e (output s, input x, y, w, z);
  // M   0              1              2
  assign s = (x|y|w|z) & (x|y|w|~z) & (x|y|~w|z)
  //          4              7                 12
            & (x|~y|w|z) & (x|~y|~w|~z) & (~x|~y|w|z)
  //          15
            & (~x|~y|~w|~z);
endmodule // ex04e

// ---------------------
// -- test_module
// ---------------------
module test_module;
  reg x, y, w, z;
  wire sa, sb, sc, sd, se;

  ex04a A (sa, x, y, z);
  ex04b B (sb, x, y, z);
  ex04c C (sc, x, y, w, z);
  ex04d D (sd, x, y, w, z);
  ex04e E (se, x, y, w, z);

  integer i;

  initial begin: start
    x=1'bx; y=1'bx; w=1'bx; z=1'bx;
  end

  initial begin: main
    $display("Guia_04 - Questao 04 - xxx yyy zzz - 999999");
    $display("x y w z = a b c d e  (varre as 16 combinacoes)");
    $monitor("%b %b %b %b = %b %b %b %b %b", x, y, w, z, sa, sb, sc, sd, se);
    for (i = 0; i < 16; i = i + 1) begin
      #1 {x, y, w, z} = i[3:0];
    end
  end
endmodule // test_module
