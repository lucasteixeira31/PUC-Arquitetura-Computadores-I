// ---------------------
// GUIA 04 - EXTRA 06
// Nome: xxx yyy zzz
// Matricula: 999999
// ---------------------
// Modulo original dado no guia (corrigido o nome de saida para S1, que no
// PDF estava com um pequeno erro de maiuscula/minuscula em "assign s1").
module FXYZ (output S1, input X, input Y, input Z);
  assign S1 = ( X | Y | ~Z ) & ( ~X | Y | ~Z );
endmodule // FXYZ

// Simplificado: (X+Y+Z').(X'+Y+Z') = Y+Z'  (consenso/distributiva)
module fxyz_simp (output s, input x, y, z);
  assign s = y | ~z;
endmodule // fxyz_simp

// SoP equivalente encontrada: soma m(0,2,3,4,6,7)
module fxyz_sop (output s, input x, y, z);
  assign s = (~x&~y&~z) | (~x&y&~z) | (~x&y&z) | (x&~y&~z) | (x&y&~z) | (x&y&z);
endmodule // fxyz_sop

// ---------------------
// -- test_module
// ---------------------
module test_module;
  reg x, y, z;
  wire s_orig, s_simp, s_sop;

  FXYZ ORIG (s_orig, x, y, z);
  fxyz_simp SIMP (s_simp, x, y, z);
  fxyz_sop SOP1 (s_sop, x, y, z);

  initial begin: start
    x=1'bx; y=1'bx; z=1'bx;
  end

  initial begin: main
    $display("Guia_04 - Extra 06 - xxx yyy zzz - 999999");
    $display("As 3 colunas devem ser sempre iguais: orig, Y+Z', SoP");
    $display("x y z = orig simp sop");
    $monitor("%b %b %b = %b    %b    %b", x, y, z, s_orig, s_simp, s_sop);
    #1 x=0; y=0; z=0;
    #1 x=0; y=0; z=1;
    #1 x=0; y=1; z=0;
    #1 x=0; y=1; z=1;
    #1 x=1; y=0; z=0;
    #1 x=1; y=0; z=1;
    #1 x=1; y=1; z=0;
    #1 x=1; y=1; z=1;
  end
endmodule // test_module
