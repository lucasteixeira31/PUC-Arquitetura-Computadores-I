// ---------------------
// GUIA 04 - QUESTAO 01
// Nome: xxx yyy zzz
// Matricula: 999999
// ---------------------
// Cada modulo implementa uma expressao original (sem simplificar), so para
// verificar a tabela-verdade calculada a mao / conferida em Python.

// a) x . ( y + z' )'
module ex01a (output s, input x, y, z);
  assign s = x & ~(y | ~z);
endmodule // ex01a

// b) ( x + y' )' . z
module ex01b (output s, input x, y, z);
  assign s = ~(x | ~y) & z;
endmodule // ex01b

// c) ( x' . y )' . z'
module ex01c (output s, input x, y, z);
  assign s = ~(~x & y) & ~z;
endmodule // ex01c

// d) ( x' . y )' . z
module ex01d (output s, input x, y, z);
  assign s = ~(~x & y) & z;
endmodule // ex01d

// e) ( x' + y' ) . ( y + z' )'
module ex01e (output s, input x, y, z);
  assign s = (~x | ~y) & ~(y | ~z);
endmodule // ex01e

// ---------------------
// -- test_module
// ---------------------
module test_module;
  reg x, y, z;
  wire sa, sb, sc, sd, se;

  ex01a A (sa, x, y, z);
  ex01b B (sb, x, y, z);
  ex01c C (sc, x, y, z);
  ex01d D (sd, x, y, z);
  ex01e E (se, x, y, z);

  initial begin: start
    x = 1'bx; y = 1'bx; z = 1'bx;
  end

  initial begin: main
    $display("Guia_04 - Questao 01 - xxx yyy zzz - 999999");
    $display("x y z = a b c d e");
    $monitor("%b %b %b = %b %b %b %b %b", x, y, z, sa, sb, sc, sd, se);
    #1 x=0; y=0; z=0;
    #1 x=0; y=0; z=1;
    #1 x=0; y=1; z=0;
    #1 x=0; y=1; z=1;
    #1 x=1; y=0; z=0;
    #1 x=1; y=0; z=1;
    #1 x=1; y=1; z=0;
    #1 x=1; y=1; z=1;
  end
endmodule // test_module

// Saidas esperadas (x y z = a b c d e):
// 000 = 0 0 1 0 0
// 001 = 0 0 0 1 1
// 010 = 0 0 0 0 0
// 011 = 0 1 0 0 0
// 100 = 0 0 1 0 0
// 101 = 1 0 0 1 1
// 110 = 0 0 1 0 0
// 111 = 0 0 0 1 0
