/*
 Guia_0201.v
 801169 - Leonardo Amaral
*/

module Guia_0201;

// define data
real x;
real power2;
integer y;

reg [7:0] b;

// actions
initial
begin : main

   $display("Guia_0201 - Tests\n");

   // a) 0,00101(2)
   x = 0;
   power2 = 1.0;
   b = 8'b00101000;
   y = 7;

   while (y >= 0)
   begin
      power2 = power2 / 2.0;

      if (b[y] == 1)
      begin
         x = x + power2;
      end

      y = y - 1;
   end

   $display("0.00101(2) = %f(10)", x);


   // b) 0,01011(2)
   x = 0;
   power2 = 1.0;
   b = 8'b01011000;
   y = 7;

   while (y >= 0)
   begin
      power2 = power2 / 2.0;

      if (b[y] == 1)
      begin
         x = x + power2;
      end

      y = y - 1;
   end

   $display("0.01011(2) = %f(10)", x);


   // c) 0,10111(2)
   x = 0;
   power2 = 1.0;
   b = 8'b10111000;
   y = 7;

   while (y >= 0)
   begin
      power2 = power2 / 2.0;

      if (b[y] == 1)
      begin
         x = x + power2;
      end

      y = y - 1;
   end

   $display("0.10111(2) = %f(10)", x);


   // d) 1,01101(2)
   // Parte inteira = 1
   x = 1;
   power2 = 1.0;
   b = 8'b01101000;
   y = 7;

   while (y >= 0)
   begin
      power2 = power2 / 2.0;

      if (b[y] == 1)
      begin
         x = x + power2;
      end

      y = y - 1;
   end

   $display("1.01101(2) = %f(10)", x);


   // e) 10,11001(2)
   // Parte inteira = 10(2) = 2(10)
   x = 2;
   power2 = 1.0;
   b = 8'b11001000;
   y = 7;

   while (y >= 0)
   begin
      power2 = power2 / 2.0;

      if (b[y] == 1)
      begin
         x = x + power2;
      end

      y = y - 1;
   end

   $display("10.11001(2) = %f(10)", x);

end // main

endmodule // Guia_0201