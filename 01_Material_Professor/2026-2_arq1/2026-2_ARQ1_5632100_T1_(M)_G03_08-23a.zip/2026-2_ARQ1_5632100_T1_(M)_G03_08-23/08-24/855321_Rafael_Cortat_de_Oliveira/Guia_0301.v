/*
Guia_0301.v
678019 - Rafael Cortat De Oliveira
*/
module Guia_0301;
    reg [5:0] a = 6'b001001;    // 1001 in 6 bits
    reg [7:0] b = 8'b00010100;  // 10100 in 8 bits
    reg [5:0] c = 6'b101011;    // 101011 in 6 bits
    reg [6:0] d = 7'b0101111;   // 101111 in 7 bits
    reg [7:0] e = 8'b00110010;  // 110010 in 8 bits
    reg [5:0] a_res;
    reg [7:0] b_res;
    reg [5:0] c_res;
    reg [6:0] d_res;
    reg [7:0] e_res;
    // actions
    initial
    begin : main
        $display ( "Guia_0301 - Tests" );
        // a.) C1,6 (1001(2)) -> 1's Complement
        a_res = ~a;
        $display ( "a.) C1,6 (%6b(2)) = %6b(2)", a, a_res );
        // b.) C1,8 (10100(2)) -> 1's Complement
        b_res = ~b;
        $display ( "b.) C1,8 (%8b(2)) = %8b(2)", b, b_res );
        // c.) C2,6 (101011(2)) -> 2's Complement
        c_res = ~c + 1;
        $display ( "c.) C2,6 (%6b(2)) = %6b(2)", c, c_res );
        // d.) C2,7 (101111(2)) -> 2's Complement
        d_res = ~d + 1;
        $display ( "d.) C2,7 (%7b(2)) = %7b(2)", d, d_res );
        // e.) C2,8 (110010(2)) -> 2's Complement
        e_res = ~e + 1;
        $display ( "e.) C2,8 (%8b(2)) = %8b(2)", e, e_res );
        
    end // main
endmodule // Guia_0301