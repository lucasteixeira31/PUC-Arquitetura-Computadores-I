/*

Guia_0302.v
678019 - Rafael Cortat De Oliveira
*/
module Guia_0302;
    reg [5:0] a = 6'b011110;    // 132(4) in 6 bits
    reg [7:0] b = 8'hE7;        // E7(16) in 8 bits
    reg [5:0] c = 6'b101101;    // 231(4) in 6 bits
    reg [9:0] d = 10'o176;      // 176(8) in 10 bits
    reg [7:0] e = 8'h7A;        // 7A(16) in 8 bits
    reg [5:0] a_res;
    reg [7:0] b_res;
    reg [5:0] c_res;
    reg [9:0] d_res;
    reg [7:0] e_res;
    // actions
    initial
    begin : main
        $display ( "Guia_0302 - Tests" );
        
        // a.) C1,6 (132(4)) -> 1's Complement
        a_res = ~a;
        $display ( "a.) C1,6 (%6b(2)) = %6b(2)", a, a_res );
        
        // b.) C1,8 (E7(16)) -> 1's Complement
        b_res = ~b;
        $display ( "b.) C1,8 (%8b(2)) = %8b(2)", b, b_res );
        
        // c.) C2,6 (231(4)) -> 2's Complement
        c_res = ~c + 1;
        $display ( "c.) C2,6 (%6b(2)) = %6b(2)", c, c_res );
        
        // d.) C2,10 (176(8)) -> 2's Complement
        d_res = ~d + 1;
        $display ( "d.) C2,10 (%10b(2)) = %10b(2)", d, d_res );
        
        // e.) C2,8 (7A(16)) -> 2's Complement
        e_res = ~e + 1;
        $display ( "e.) C2,8 (%8b(2)) = %8b(2)", e, e_res );
        
    end // main
endmodule // Guia_0302