/*
Guia_0202.v
678019 - Rafael Cortat De Oliveira
*/
module Guia_0202;
// define data
real base10[0:4]; // decimal
integer base10int[0:4]; // decimal
integer y = 7 ; // counter
reg [7:0] b = 0 ; // binary
// actions
initial
begin : main
$display ( "Guia_0202 - Tests" );
for (int i =0; i < 5; i++) begin
y = 7;
 b = 0;
$display ( "decimal = %f" , base10[i] );
while ( base10[i] > 0 && y >= 0 )
begin
if ( base10[i]*2 >= 1 )
begin
b[y] = 1;
base10[i] = base10[i]*2.0 - 1.0;
end
else
begin
b[y] = 0;
base10[i] = base10[i]*2.0;
end // end if
$display ( "base2 = %8b.%8b", base10int[i],b);
y=y-1;
end // end while
end
end // main
endmodule // Guia_0202