/*
 Guia_0301.v
 801169 - Leonardo Amaral
*/

module Guia_0301;

reg [5:0]  a = 6'b001001;
reg [7:0]  b = 8'b00010100;
reg [5:0]  c = 6'b101011;
reg [6:0]  d = 7'b0101111;
reg [7:0]  e = 8'b00110010;

reg [5:0]  c1_a;
reg [7:0]  c1_b;
reg [5:0]  c2_c;
reg [6:0]  c2_d;
reg [7:0]  c2_e;

initial
begin : main

    $display("Guia_0301 - Tests");

    c1_a = ~a;
    c1_b = ~b;

    c2_c = ~c + 1;
    c2_d = ~d + 1;
    c2_e = ~e + 1;

    $display("C1,6 (1001)   = %6b", c1_a);
    $display("C1,8 (10100)  = %8b", c1_b);
    $display("C2,6 (101011) = %6b", c2_c);
    $display("C2,7 (101111) = %7b", c2_d);
    $display("C2,8 (110010) = %8b", c2_e);

end

endmodule