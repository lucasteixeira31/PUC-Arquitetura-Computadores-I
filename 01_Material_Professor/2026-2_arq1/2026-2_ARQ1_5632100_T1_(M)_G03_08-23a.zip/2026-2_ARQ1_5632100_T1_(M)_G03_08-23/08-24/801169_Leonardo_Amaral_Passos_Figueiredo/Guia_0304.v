/*
 Guia_0304.v
 801169 - Leonardo Amaral
*/

module Guia_0304;

reg signed [11:0] a;
reg signed [11:0] b;
reg signed [11:0] c;
reg signed [11:0] resultado;

initial
begin : main

    $display("Guia_0304 - Tests");

    // 11101(2) - 01011(2)
    a = 12'b0000_0001_1101;
    b = 12'b0000_0000_1011;

    resultado = a - b;

    $display("11101 - 1011 = %b = %d",
             resultado, resultado);


    // 101,1011 - 10,01
    // Utilizando 4 bits para a parte fracionaria:
    // 101.1011 = 1011011
    // 10.0100 = 0100100

    a = 12'b0000_0101_1011;
    b = 12'b0000_0010_0100;

    resultado = a - b;

    $display("101.1011 - 10.01 = %b",
             resultado);


    // 312(4) - 132(4)
    // 312(4) = 54
    // 132(4) = 30

    a = 54;
    b = 30;

    resultado = a - b;

    $display("312(4) - 132(4) = %d", resultado);


    // 647(8) - 256(8)

    a = 12'o647;
    b = 12'o256;

    resultado = a - b;

    $display("647(8) - 256(8) = %d", resultado);


    // A4C(16) - B7F(16)

    a = 12'hA4C;
    b = 12'hB7F;

    resultado = a - b;

    $display("A4C(16) - B7F(16) = %d", resultado);

end

endmodule