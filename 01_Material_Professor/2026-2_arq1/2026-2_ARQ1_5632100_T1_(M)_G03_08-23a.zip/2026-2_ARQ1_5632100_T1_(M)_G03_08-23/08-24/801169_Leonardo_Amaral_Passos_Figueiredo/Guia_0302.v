/*
 Guia_0302.v
 801169 - Leonardo Amaral
*/

module Guia_0302;

reg [5:0] a = 6'b011110;       // 132(4)
reg [7:0] b = 8'b11100111;     // E7(16)
reg [5:0] c = 6'b101101;       // 231(4)
reg [9:0] d = 10'b0011111110;  // 176(8)
reg [7:0] e = 8'b01111010;     // 7A(16)

initial
begin : main

    $display("Guia_0302 - Tests");

    $display("C1,6 (132(4)) = %6b", ~a);
    $display("C1,8 (E7(16)) = %8b", ~b);

    $display("C2,6 (231(4)) = %6b", ~c + 1);
    $display("C2,10(176(8)) = %10b", ~d + 1);
    $display("C2,8 (7A(16)) = %8b", ~e + 1);

end

endmodule