/*
 Guia_0303.v
 801169 - Leonardo Amaral
*/

module Guia_0303;

reg signed [4:0] a = 5'b10101;
reg signed [5:0] b = 6'b110111;
reg signed [5:0] c = 6'b100110;
reg signed [6:0] d = 7'b1011101;
reg signed [6:0] e = 7'b1110111;

reg [4:0] mag_a;
reg [5:0] mag_b;
reg [5:0] mag_c;
reg [6:0] mag_d;
reg [6:0] mag_e;

initial
begin : main

    $display("Guia_0303 - Tests");

    mag_a = ~(a - 1);
    mag_b = ~(b - 1);
    mag_c = ~(c - 1);
    mag_d = ~(d - 1);
    mag_e = ~(e - 1);

    $display("a = %5b -> modulo = %5b = %d",
             a, mag_a, mag_a);

    $display("b = %6b -> modulo = %6b = %d",
             b, mag_b, mag_b);

    $display("c = %6b -> modulo = %6b",
             c, mag_c);

    $display("d = %7b -> modulo = %7b",
             d, mag_d);

    $display("e = %7b -> modulo = %7b = %h",
             e, mag_e, mag_e);

end

endmodule