// Nome: Vinicius Alves Sousa
// Matricula: 825902
// Arquivo: Guia_0702.v

module Guia_0702 (
    output y,
    input a,
    input b,
    input select
);
    wire orOut;
    wire norOut;
    wire notSelect;
    wire optionNor;
    wire optionOr;

    or   OR1  (orOut, a, b);
    nor  NOR1 (norOut, a, b);
    not  NOT1 (notSelect, select);
    and  AND1 (optionNor, norOut, notSelect);
    and  AND2 (optionOr, orOut, select);
    or   OR2  (y, optionNor, optionOr);
endmodule
