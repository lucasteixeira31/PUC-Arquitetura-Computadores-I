// Nome: Vinicius Alves Sousa
// Matricula: 825902
// Arquivo: Guia_0704.v

module Guia_0704 (
    output y,
    input a,
    input b,
    input s0,
    input s1
);
    wire orOut, norOut, xorOut, xnorOut;
    wire notS0, notS1;
    wire optionOr, optionNor, optionXnor, optionXor;

    or   OR1   (orOut, a, b);
    nor  NOR1  (norOut, a, b);
    xor  XOR1  (xorOut, a, b);
    xnor XNOR1 (xnorOut, a, b);
    not  NOT1  (notS0, s0);
    not  NOT2  (notS1, s1);

    and AND1 (optionOr,   orOut,   notS1, notS0);
    and AND2 (optionNor,  norOut,  notS1, s0);
    and AND3 (optionXnor, xnorOut, s1,    notS0);
    and AND4 (optionXor,  xorOut,  s1,    s0);
    or  OR2  (y, optionOr, optionNor, optionXnor, optionXor);
endmodule
