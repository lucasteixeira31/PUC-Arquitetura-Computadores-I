Nome: Vinicius Alves Sousa
Matricula: 825902
Disciplina: Arquitetura de Computadores I

Esta pasta contem os cinco exercicios de unidades logicas:
Guia_0701.v, Guia_0702.v, Guia_0703.v, Guia_0704.v e Guia_0705.v.

O arquivo testes/testbench_guias.v contem o modulo de testes dos cinco
exercicios. O resultado da simulacao esta em resultados/resultado_simulacao.txt.

Os arquivos .v podem ser compilados com Icarus Verilog usando:
iverilog -o sim.vvp testes/testbench_guias.v Guia_0701.v Guia_0702.v Guia_0703.v Guia_0704.v Guia_0705.v
vvp sim.vvp

Nao foram incluidos arquivos executaveis ou arquivos intermediarios.

// OBS.: FOI BOM TER INCLUÍDO OS ARQUIVOS DE prompt E skills.
//       ESPERO QUE TENHAM AJUDADO A ORGANIZAR-SE MELHOR.
