// Nome: Vinicius Alves Sousa
// Matricula: 825902
// Arquivo: testbench_guias.v

module testbench_guias;
    reg a, b, select, porta, grupo, s0, s1, s2;
    wire y0701, y0702, y0703, y0704, y0705;

    Guia_0701 g1(y0701, a, b, select);
    Guia_0702 g2(y0702, a, b, select);
    Guia_0703 g3(y0703, a, b, porta, grupo);
    Guia_0704 g4(y0704, a, b, s0, s1);
    Guia_0705 g5(y0705, a, b, s0, s1, s2);

    initial begin
        $display("Guia_0701: a b select | y");
        for (a = 0; a <= 1; a = a + 1)
            for (b = 0; b <= 1; b = b + 1)
                for (select = 0; select <= 1; select = select + 1) begin
                    #1;
                    $display("             %b %b    %b    | %b", a,b,select,y0701);
                end

        $display("Guia_0702: a b select | y");
        for (a = 0; a <= 1; a = a + 1)
            for (b = 0; b <= 1; b = b + 1)
                for (select = 0; select <= 1; select = select + 1) begin
                    #1;
                    $display("             %b %b    %b    | %b", a,b,select,y0702);
                end

        $display("Guia_0703: a b porta grupo | y");
        for (a = 0; a <= 1; a = a + 1)
            for (b = 0; b <= 1; b = b + 1)
                for (porta = 0; porta <= 1; porta = porta + 1)
                    for (grupo = 0; grupo <= 1; grupo = grupo + 1) begin
                        #1;
                        $display("             %b %b    %b     %b    | %b", a,b,porta,grupo,y0703);
                    end

        $display("Guia_0704: a b s0 s1 | y");
        for (a = 0; a <= 1; a = a + 1)
            for (b = 0; b <= 1; b = b + 1)
                for (s0 = 0; s0 <= 1; s0 = s0 + 1)
                    for (s1 = 0; s1 <= 1; s1 = s1 + 1) begin
                        #1;
                        $display("             %b %b  %b  %b  | %b", a,b,s0,s1,y0704);
                    end

        $display("Guia_0705: a b s0 s1 s2 | y");
        for (a = 0; a <= 1; a = a + 1)
            for (b = 0; b <= 1; b = b + 1)
                for (s0 = 0; s0 <= 1; s0 = s0 + 1)
                    for (s1 = 0; s1 <= 1; s1 = s1 + 1)
                        for (s2 = 0; s2 <= 1; s2 = s2 + 1) begin
                            #1;
                            $display("             %b %b  %b  %b  %b  | %b", a,b,s0,s1,s2,y0705);
                        end
        $finish;
    end
endmodule
