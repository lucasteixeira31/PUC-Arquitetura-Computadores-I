// Nome: Vinicius Alves Sousa
// Matricula: 825902
// Arquivo: Guia_0703.v

module Guia_0703 (
    output y,
    input a,
    input b,
    input porta,
    input grupo
);
    wire andOut, nandOut, orOut, norOut;
    wire notPorta, notGrupo;
    wire grupoAndNand, grupoOrNor;
    wire optionNand, optionAnd, optionNor, optionOr;
    wire selectAndGroup, selectOrGroup;

    and  AND1 (andOut, a, b);
    nand NAND1 (nandOut, a, b);
    or   OR1  (orOut, a, b);
    nor  NOR1 (norOut, a, b);
    not  NOT1 (notPorta, porta);
    not  NOT2 (notGrupo, grupo);

    and  AND2 (optionNand, nandOut, notPorta);
    and  AND3 (optionAnd, andOut, porta);
    or   OR2  (grupoAndNand, optionNand, optionAnd);

    and  AND4 (optionNor, norOut, notPorta);
    and  AND5 (optionOr, orOut, porta);
    or   OR3  (grupoOrNor, optionNor, optionOr);

    and  AND6 (selectAndGroup, grupoAndNand, grupo);
    and  AND7 (selectOrGroup, grupoOrNor, notGrupo);
    or   OR4  (y, selectAndGroup, selectOrGroup);
endmodule
