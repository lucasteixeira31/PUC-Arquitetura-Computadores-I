// Nome: Vinicius Alves Sousa
// Matricula: 825902
// Arquivo: Guia_0705.v

module Guia_0705 (
    output y,
    input a,
    input b,
    input s0,
    input s1,
    input s2
);
    wire notOut, andOut, nandOut, orOut, norOut, xorOut, xnorOut;
    wire notS0, notS1, notS2;
    wire optionNot, optionAnd, optionNand, optionOr;
    wire optionNor, optionXor, optionXnor;

    not  NOT_A  (notOut, a);
    and  AND1   (andOut, a, b);
    nand NAND1  (nandOut, a, b);
    or   OR1    (orOut, a, b);
    nor  NOR1   (norOut, a, b);
    xor  XOR1   (xorOut, a, b);
    xnor XNOR1  (xnorOut, a, b);
    not  NOT_S0 (notS0, s0);
    not  NOT_S1 (notS1, s1);
    not  NOT_S2 (notS2, s2);

    and SEL0 (optionNot,  notOut,  notS2, notS1, notS0);
    and SEL1 (optionAnd,  andOut,  notS2, notS1, s0);
    and SEL2 (optionNand, nandOut, notS2, s1,    notS0);
    and SEL3 (optionOr,   orOut,   notS2, s1,    s0);
    and SEL4 (optionNor,  norOut,  s2,    notS1, notS0);
    and SEL5 (optionXor,  xorOut,  s2,    notS1, s0);
    and SEL6 (optionXnor, xnorOut, s2,    s1,    notS0);

    or OR_FINAL (y, optionNot, optionAnd, optionNand, optionOr,
                 optionNor, optionXor, optionXnor);
endmodule
