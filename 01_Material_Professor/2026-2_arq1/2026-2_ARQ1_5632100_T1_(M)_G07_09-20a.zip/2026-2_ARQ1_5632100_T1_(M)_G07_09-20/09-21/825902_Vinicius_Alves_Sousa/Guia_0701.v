// Nome: Vinicius Alves Sousa
// Matricula: 825902
// Arquivo: Guia_0701.v

module Guia_0701 (
    output y,
    input a,
    input b,
    input select
);
    wire andOut;
    wire nandOut;
    wire notSelect;
    wire optionNand;
    wire optionAnd;

    and  AND1 (andOut, a, b);
    nand NAND1 (nandOut, a, b);
    not  NOT1 (notSelect, select);
    and  AND2 (optionNand, nandOut, notSelect);
    and  AND3 (optionAnd, andOut, select);
    or   OR1  (y, optionNand, optionAnd);
endmodule
