// Guia_0702
// Nome: Antonio Victor Oliveira Goncalves
// Matricula: 771380

module lu(output s, input a, input b, input select);
wire or_result, nor_result, not_select, s_or, s_nor;
or OR1(or_result,a,b);
nor NOR1(nor_result,a,b);
not NOT1(not_select,select);
and AND1(s_or,or_result,select);
and AND2(s_nor,nor_result,not_select);
or OR2(s,s_or,s_nor);
endmodule

module test_lu;
reg a,b,select;
wire s;
lu modulo(s,a,b,select);
initial begin
$display("Guia_0702 - LU OR/NOR");
$display("a b select | s");
a=0; b=0; select=0;
#1 $monitor("%b %b    %b    | %b",a,b,select,s);
#1 select=1;
#1 a=0; b=1; select=0;
#1 select=1;
#1 a=1; b=0; select=0;
#1 select=1;
#1 a=1; b=1; select=0;
#1 select=1;
#1 $finish;
end
endmodule
