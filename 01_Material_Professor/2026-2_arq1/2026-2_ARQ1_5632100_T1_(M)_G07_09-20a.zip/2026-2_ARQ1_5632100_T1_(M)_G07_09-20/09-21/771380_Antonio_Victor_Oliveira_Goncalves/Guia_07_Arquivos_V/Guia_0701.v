// Guia_0701 
// Nome: Antonio Victor Oliveira Goncalves
// Matricula: 771380

module lu(output s, input a, input b, input select);
wire and_result, nand_result, not_select, s_and, s_nand;
and AND1(and_result,a,b);
nand NAND1(nand_result,a,b);
not NOT1(not_select,select);
and AND2(s_and,and_result,select);
and AND3(s_nand,nand_result,not_select);
or OR1(s,s_and,s_nand);
endmodule

module test_lu;
reg a,b,select;
wire s;
lu modulo(s,a,b,select);
initial begin
$display("Guia_0701 - LU AND/NAND");
$display("a b select | s");
a=0; b=0; select=0;
#1 $monitor("%b %b    %b    | %b",a,b,select,s);
#1 select=1;
#1 a=0; b=1; select=0;
#1 select=1;
#1 a=1; b=0; select=0;
#1 select=1;
#1 a=1; b=1; select=0;
#1 select=1;
#1 $finish;
end
endmodule
