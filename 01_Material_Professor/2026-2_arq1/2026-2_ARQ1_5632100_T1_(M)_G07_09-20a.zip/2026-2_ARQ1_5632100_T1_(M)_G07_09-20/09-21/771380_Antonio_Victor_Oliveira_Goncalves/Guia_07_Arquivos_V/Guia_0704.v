// Guia_0704
// Nome: Antonio Victor Oliveira Goncalves
// Matricula: 771380

module lu(output s,input a,input b,input select1,input select0);
wire or_result,nor_result,xor_result,xnor_result,n1,n0;
wire p_or,p_nor,p_xnor,p_xor;
or O1(or_result,a,b);
nor N1(nor_result,a,b);
xor X1(xor_result,a,b);
xnor X2(xnor_result,a,b);
not N2(n1,select1);
not N3(n0,select0);
and A1(p_or,or_result,n1,n0);
and A2(p_nor,nor_result,n1,select0);
and A3(p_xnor,xnor_result,select1,n0);
and A4(p_xor,xor_result,select1,select0);
or O2(s,p_or,p_nor,p_xnor,p_xor);
endmodule

module test_lu;
reg a,b,select1,select0;
wire s;
lu modulo(s,a,b,select1,select0);
initial begin
$display("Guia_0704 - LU OR/NOR e XOR/XNOR");
$display("a b sel1 sel0 | s");
a=0;b=0;select1=0;select0=0;
#1 $monitor("%b %b   %b    %b  | %b",a,b,select1,select0,s);
#1 select0=1;
#1 select1=1;select0=0;
#1 select0=1;
#1 a=0;b=1;select1=0;select0=0;
#1 select0=1;
#1 select1=1;select0=0;
#1 select0=1;
#1 a=1;b=0;select1=0;select0=0;
#1 select0=1;
#1 select1=1;select0=0;
#1 select0=1;
#1 a=1;b=1;select1=0;select0=0;
#1 select0=1;
#1 select1=1;select0=0;
#1 select0=1;
#1 $finish;
end
endmodule
