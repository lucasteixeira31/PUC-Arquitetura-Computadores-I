// Guia_0705
// Nome: Antonio Victor Oliveira Goncalves
// Matricula: 771380

module lu(output s,input a,input b,input sel2,input sel1,input sel0);
wire not_a,and_r,nand_r,or_r,nor_r,xor_r,xnor_r;
wire n2,n1,n0,p0,p1,p2,p3,p4,p5,p6;
not N1(not_a,a);
and A1(and_r,a,b);
nand A2(nand_r,a,b);
or O1(or_r,a,b);
nor O2(nor_r,a,b);
xor X1(xor_r,a,b);
xnor X2(xnor_r,a,b);
not N2(n2,sel2);
not N3(n1,sel1);
not N4(n0,sel0);
and A3(p0,not_a,n2,n1,n0);
and A4(p1,and_r,n2,n1,sel0);
and A5(p2,nand_r,n2,sel1,n0);
and A6(p3,or_r,n2,sel1,sel0);
and A7(p4,nor_r,sel2,n1,n0);
and A8(p5,xor_r,sel2,n1,sel0);
and A9(p6,xnor_r,sel2,sel1,n0);
or O3(s,p0,p1,p2,p3,p4,p5,p6);
endmodule

module test_lu;
reg a,b,sel2,sel1,sel0;
wire s;
lu modulo(s,a,b,sel2,sel1,sel0);
initial begin
$display("Guia_0705 - LU com 7 operacoes");
$display("a b sel2 sel1 sel0 | s");
a=0;b=0;sel2=0;sel1=0;sel0=0;
#1 $monitor("%b %b   %b    %b    %b  | %b",a,b,sel2,sel1,sel0,s);
#1 sel0=1; #1 sel1=1;sel0=0; #1 sel0=1;
#1 sel2=1;sel1=0;sel0=0; #1 sel0=1; #1 sel1=1;sel0=0; #1 sel0=1;
#1 a=0;b=1;sel2=0;sel1=0;sel0=0;
#1 sel0=1; #1 sel1=1;sel0=0; #1 sel0=1;
#1 sel2=1;sel1=0;sel0=0; #1 sel0=1; #1 sel1=1;sel0=0; #1 sel0=1;
#1 a=1;b=0;sel2=0;sel1=0;sel0=0;
#1 sel0=1; #1 sel1=1;sel0=0; #1 sel0=1;
#1 sel2=1;sel1=0;sel0=0; #1 sel0=1; #1 sel1=1;sel0=0; #1 sel0=1;
#1 a=1;b=1;sel2=0;sel1=0;sel0=0;
#1 sel0=1; #1 sel1=1;sel0=0; #1 sel0=1;
#1 sel2=1;sel1=0;sel0=0; #1 sel0=1; #1 sel1=1;sel0=0; #1 sel0=1;
#1 $finish;
end
endmodule
