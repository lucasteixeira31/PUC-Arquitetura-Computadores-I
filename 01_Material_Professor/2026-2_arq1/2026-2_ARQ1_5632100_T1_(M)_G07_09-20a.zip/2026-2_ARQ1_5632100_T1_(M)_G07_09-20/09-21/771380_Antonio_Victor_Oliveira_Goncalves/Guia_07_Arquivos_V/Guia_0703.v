// Guia_0703
// Nome: Antonio Victor Oliveira Goncalves
// Matricula: 771380

module lu(output s, input a, input b, input select_port, input select_group);
wire and_result,nand_result,or_result,nor_result;
wire not_port,not_group,and_group,or_group;
wire and_sel,nand_sel,or_sel,nor_sel;
wire s_and_group,s_or_group;

not N1(not_port,select_port);
not N2(not_group,select_group);

and A1(and_result,a,b);
nand N3(nand_result,a,b);
or O1(or_result,a,b);
nor N4(nor_result,a,b);

and A2(and_sel,and_result,select_port);
and A3(nand_sel,nand_result,not_port);
or O2(and_group,and_sel,nand_sel);

and A4(or_sel,or_result,select_port);
and A5(nor_sel,nor_result,not_port);
or O3(or_group,or_sel,nor_sel);

and A6(s_and_group,and_group,select_group);
and A7(s_or_group,or_group,not_group);
or O4(s,s_and_group,s_or_group);
endmodule

module test_lu;
reg a,b,select_port,select_group;
wire s;
lu modulo(s,a,b,select_port,select_group);
initial begin
$display("Guia_0703 - LU AND/NAND e OR/NOR");
$display("a b port group | s");
a=0;b=0;select_group=0;select_port=0;
#1 $monitor("%b %b   %b    %b   | %b",a,b,select_port,select_group,s);
#1 select_port=1;
#1 select_group=1;select_port=0;
#1 select_port=1;
#1 a=0;b=1;select_group=0;select_port=0;
#1 select_port=1;
#1 select_group=1;select_port=0;
#1 select_port=1;
#1 a=1;b=0;select_group=0;select_port=0;
#1 select_port=1;
#1 select_group=1;select_port=0;
#1 select_port=1;
#1 a=1;b=1;select_group=0;select_port=0;
#1 select_port=1;
#1 select_group=1;select_port=0;
#1 select_port=1;
#1 $finish;
end
endmodule
