/*
 Guia_0702.v
 801169 - Leonardo Amaral

 Unidade Logica (LU)

 Entradas:
 X, Y = operandos de 1 bit
 SEL  = selecao

 Operacoes:
 OR  = X OR Y
 NOR = X NOR Y

 Selecao:
 SEL = 0 -> NOR
 SEL = 1 -> OR

 Implementacao utilizando portas nativas.
 Nao utiliza switch-case nem operador ternario.
*/

module Guia_0702(
    output saida_or,
    output saida_nor,
    output saida,
    input x,
    input y,
    input sel
);

wire sel_not;
wire or_sel;
wire nor_sel;

// Operacoes da Unidade Logica

or  (saida_or,  x, y);
nor (saida_nor, x, y);

/*
  Circuito de selecao
 
  SEL = 1 -> seleciona OR
  SEL = 0 -> seleciona NOR
 */

not (sel_not, sel);

and (or_sel,  sel,     saida_or);
and (nor_sel, sel_not, saida_nor);

or  (saida, or_sel, nor_sel);

endmodule