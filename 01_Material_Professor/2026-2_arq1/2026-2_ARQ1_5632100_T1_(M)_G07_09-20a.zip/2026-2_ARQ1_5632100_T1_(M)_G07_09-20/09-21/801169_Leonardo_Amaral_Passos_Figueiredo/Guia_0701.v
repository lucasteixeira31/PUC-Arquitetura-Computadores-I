/*
 Guia_0701.v
 801169 - Leonardo Amaral

 Unidade Logica (LU)

 Entradas:
 X, Y = operandos de 1 bit
 SEL  = selecao

 Operacoes paralelas:
 AND  = X AND Y
 NAND = X NAND Y

 Selecao:
 SEL = 0 -> NAND
 SEL = 1 -> AND

 Implementacao utilizando portas nativas.
 Nao utiliza switch-case nem operador ternario.
*/

module Guia_0701(
    output saida_and,
    output saida_nand,
    output saida,
    input x,
    input y,
    input sel
);

wire sel_not;
wire and_sel;
wire nand_sel;

/*
  Operacoes da Unidade Logica
  As duas sao calculadas em paralelo.
 */

and  (saida_and,  x, y);
nand (saida_nand, x, y);

/*
  Circuito de selecao
 
  SEL = 1:
    and_sel = AND
    nand_sel = 0
 
  SEL = 0:
   and_sel = 0
   nand_sel = NAND
 */

not (sel_not, sel);

and (and_sel,  sel,     saida_and);
and (nand_sel, sel_not, saida_nand);

or  (saida, and_sel, nand_sel);

endmodule