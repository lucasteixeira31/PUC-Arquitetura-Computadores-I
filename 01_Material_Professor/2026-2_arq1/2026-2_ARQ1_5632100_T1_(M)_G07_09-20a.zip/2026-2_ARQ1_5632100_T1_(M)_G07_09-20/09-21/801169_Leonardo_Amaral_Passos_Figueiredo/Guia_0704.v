/*
 Guia_0704.v
 801169 - Leonardo Amaral

 Unidade Logica (LU)

 Entradas:
 X, Y = operandos de 1 bit
 SEL1, SEL0 = selecao da operacao

 Operacoes:
 00 -> OR
 01 -> NOR
 10 -> XOR
 11 -> XNOR

 A saida e unica e seleciona uma das quatro operacoes.

 Implementacao utilizando apenas portas nativas.
 Nao utiliza switch-case nem operador ternario.
*/

module Guia_0704(
    output saida,
    input x,
    input y,
    input sel1,
    input sel0
);

wire resultado_or;
wire resultado_nor;
wire resultado_xor;
wire resultado_xnor;

wire sel1_not;
wire sel0_not;

wire selecao_or;
wire selecao_nor;
wire selecao_xor;
wire selecao_xnor;

// Operacoes logicas
or   (resultado_or,   x, y);
nor  (resultado_nor, x, y);
xor  (resultado_xor, x, y);
xnor (resultado_xnor, x, y);

// Inversores das selecoes
not (sel1_not, sel1);
not (sel0_not, sel0);

// Selecao 4x1
// 00 -> OR
and (selecao_or, sel1_not, sel0_not, resultado_or);

// 01 -> NOR
and (selecao_nor, sel1_not, sel0, resultado_nor);

// 10 -> XOR
and (selecao_xor, sel1, sel0_not, resultado_xor);

// 11 -> XNOR
and (selecao_xnor, sel1, sel0, resultado_xnor);

// Saida unica
or (saida, selecao_or, selecao_nor, selecao_xor, selecao_xnor);

endmodule