/*
 Guia_0703.v
 801169 - Leonardo Amaral

 Unidade Logica (LU)

 Entradas:
 X, Y = operandos de 1 bit

 SEL1 = selecao da operacao dentro do grupo
        0 -> AND / OR
        1 -> NAND / NOR

 SEL2 = selecao do grupo
        0 -> AND / NAND
        1 -> OR / NOR

 Operacoes:
 Grupo 1:
   AND
   NAND

 Grupo 2:
   OR
   NOR

 Saida:
   Uma unica saida selecionada pelas duas chaves.

 Nao utiliza switch-case nem operador ternario.
*/

module Guia_0703(
    output saida,
    input x,
    input y,
    input sel1,
    input sel2
);

wire and_result;
wire nand_result;
wire or_result;
wire nor_result;

wire sel1_not;
wire sel2_not;

wire and_selected;
wire nand_selected;
wire grupo_and_nand;

wire or_selected;
wire nor_selected;
wire grupo_or_nor;

// Operacoes LOGICAS

// Grupo AND  NAND
and  (and_result,  x, y);
nand (nand_result, x, y);

// Grupo OR NOR
or   (or_result,  x, y);
nor  (nor_result, x, y);


// INVERSORES DA CHAVE 

not (sel1_not, sel1);
not (sel2_not, sel2);


/*
 
  PRIMEIRA CHAVE 2x1
 
  SEL1:
    0 -> AND / OR
    1 -> NAND / NOR
 
  Dentro de cada grupo:
    Grupo AND/NAND:
      SEL1=0 -> AND
      SEL1=1 -> NAND
 
    Grupo OR/NOR:
      SEL1=0 -> OR
      SEL1=1 -> NOR

 */

// Selecao AND/NAND 
and (and_selected,  sel1_not, and_result);
and (nand_selected, sel1,     nand_result);

or  (grupo_and_nand, and_selected, nand_selected);


// Selecao OR/NOR 
and (or_selected,  sel1_not, or_result);
and (nor_selected, sel1,     nor_result);

or  (grupo_or_nor, or_selected, nor_selected);


/*

 SEGUNDA CHAVE 2x1

 SEL2:
    0 -> grupo AND/NAND
    1 -> grupo OR/NOR

 */

and (saida_and_grupo, sel2_not, grupo_and_nand);
and (saida_or_grupo,  sel2,     grupo_or_nor);

or  (saida, saida_and_grupo, saida_or_grupo);

endmodule