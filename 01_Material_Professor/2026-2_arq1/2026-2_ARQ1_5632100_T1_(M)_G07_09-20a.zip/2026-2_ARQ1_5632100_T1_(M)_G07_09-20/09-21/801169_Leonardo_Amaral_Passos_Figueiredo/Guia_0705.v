/*
 Guia_0705.v
 801169 - Leonardo Amaral

 Unidade Logica (LU)

 Operacoes:
 000 -> NOT
 001 -> AND
 010 -> NAND
 011 -> OR
 100 -> NOR
 101 -> XOR
 110 -> XNOR

 As operacoes sao realizadas simultaneamente.
 Apenas uma operacao e selecionada para a saida.

 Entradas:
 X, Y = operandos de 1 bit
 SEL2, SEL1, SEL0 = selecao da operacao

 Implementacao utilizando portas nativas.
 Nao utiliza switch-case nem operador ternario.
*/

module Guia_0705(
    output saida,
    input x,
    input y,
    input sel2,
    input sel1,
    input sel0
);

wire resultado_not;
wire resultado_and;
wire resultado_nand;
wire resultado_or;
wire resultado_nor;
wire resultado_xor;
wire resultado_xnor;

wire sel2_not;
wire sel1_not;
wire sel0_not;

wire selecao_not;
wire selecao_and;
wire selecao_nand;
wire selecao_or;
wire selecao_nor;
wire selecao_xor;
wire selecao_xnor;

// Operacoes logicas simultaneas

not  (resultado_not, x);
and  (resultado_and, x, y);
nand (resultado_nand, x, y);
or   (resultado_or, x, y);
nor  (resultado_nor, x, y);
xor  (resultado_xor, x, y);
xnor (resultado_xnor, x, y);

// Inversores dos sinais de selecao

not (sel2_not, sel2);
not (sel1_not, sel1);
not (sel0_not, sel0);

// Selecao 7x1
//
// 000 -> NOT
and (
    selecao_not,
    sel2_not,
    sel1_not,
    sel0_not,
    resultado_not
);

// 001 -> AND
and (
    selecao_and,
    sel2_not,
    sel1_not,
    sel0,
    resultado_and
);

// 010 -> NAND
and (
    selecao_nand,
    sel2_not,
    sel1,
    sel0_not,
    resultado_nand
);

// 011 -> OR
and (
    selecao_or,
    sel2_not,
    sel1,
    sel0,
    resultado_or
);

// 100 -> NOR
and (
    selecao_nor,
    sel2,
    sel1_not,
    sel0_not,
    resultado_nor
);

// 101 -> XOR
and (
    selecao_xor,
    sel2,
    sel1_not,
    sel0,
    resultado_xor
);

// 110 -> XNOR
and (
    selecao_xnor,
    sel2,
    sel1,
    sel0_not,
    resultado_xnor
);

// Saida unica
or (
    saida,
    selecao_not,
    selecao_and,
    selecao_nand,
    selecao_or,
    selecao_nor,
    selecao_xor,
    selecao_xnor
);

endmodule