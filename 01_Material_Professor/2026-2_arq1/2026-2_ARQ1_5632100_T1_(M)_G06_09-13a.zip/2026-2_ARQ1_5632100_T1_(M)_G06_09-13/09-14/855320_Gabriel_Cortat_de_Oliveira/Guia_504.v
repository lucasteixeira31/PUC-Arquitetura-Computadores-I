// -------------------------
// Guia_0501.v - GATES
// Nome: Gabriel Cortat Oliveira
// Matricula: 055320
// -------------------------
// -------------------------
// f5_4
// m a b s
// 0 0 0 1
// 1 0 0 0
// 2 1 0 1
// 3 1 1 1
//
// -------------------------
module f5_4 ( output s,
 input a,
 input b );
// definir dado local
 wire OUT;
 wire B;
 

// descrever por portas
 nor NORB ( B, b, b);
 nor NOR2 ( OUT, a, B );
 nor nor3 ( s, OUT, OUT);
endmodule // f5_4
