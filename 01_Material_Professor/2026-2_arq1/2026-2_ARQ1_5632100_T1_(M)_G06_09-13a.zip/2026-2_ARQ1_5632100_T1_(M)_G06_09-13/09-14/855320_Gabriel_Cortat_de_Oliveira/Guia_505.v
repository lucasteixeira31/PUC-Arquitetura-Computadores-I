// -------------------------
// Guia_0505.v - GATES
// Nome: Gabriel Cortat Oliveira
// Matricula: 055320
// -------------------------
// -------------------------
// f5_5
// m a b s
// 0 0 0 0
// 1 0 1 1
// 2 1 0 1
// 3 1 1 0
//
// -------------------------
module f5_6 ( output s,
 input a,
 input b );
// definir dado local
 wire A;
 wire B;
 wire C;
 wire D;

// descrever por portas
 nand dualInput(C, a, b);
 nand AB2(B, C, b);
 nand AB1(A, a, C);
 nand final(s, A, B);
endmodule // f5_6
