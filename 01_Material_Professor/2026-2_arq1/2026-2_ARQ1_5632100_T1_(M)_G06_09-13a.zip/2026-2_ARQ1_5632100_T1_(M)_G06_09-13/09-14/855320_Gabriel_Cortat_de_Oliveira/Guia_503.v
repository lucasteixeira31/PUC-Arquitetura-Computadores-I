// -------------------------
// Guia_0501.v - GATES
// Nome: Gabriel Cortat Oliveira
// Matricula: 055320
// -------------------------
// -------------------------
// f5_3
// m a b s
// 0 0 0 1
// 1 0 1 1
// 2 1 0 1
// 3 1 1 0
//
// -------------------------
module f5_3 ( output s,
 input a,
 input b );
// definir dado local
 wire A;
 wire B;
 

// descrever por portas
 nand nandA ( A, a, a);
 nand nandB ( B, b, b); );
 nand nand3 ( s, A, B );
endmodule // f5_3
