// -------------------------
// Guia_0501.v - GATES
// Nome: Gabriel Cortat Oliveira
// Matricula: 055320
// -------------------------
// -------------------------
// f5_1
// m a b s
// 0 0 0 0
// 1 0 1 1 <- a'.b
// 2 1 0 0
// 3 1 1 0
//
// -------------------------
module f5_1 ( output s,
 input a,
 input b );
// definir dado local
 wire not_a;
 wire inverter;
// descrever por portas
 nand NAND1 ( not_a, a, a);
 nand NAND2 ( inverter, not_a, b );
 nand NAND4 ( s, inverter, inverter );
endmodule // f5_1
