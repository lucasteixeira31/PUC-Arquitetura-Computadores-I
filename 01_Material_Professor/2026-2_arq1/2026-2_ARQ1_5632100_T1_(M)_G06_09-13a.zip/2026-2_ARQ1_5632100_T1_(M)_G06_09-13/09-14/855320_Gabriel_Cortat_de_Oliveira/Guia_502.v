// -------------------------
// Guia_0501.v - GATES
// Nome: Gabriel Cortat Oliveira
// Matricula: 055320
// -------------------------
// -------------------------
// f5_2
// m a b s
// 0 0 0 1
// 1 0 1 0
// 2 1 0 1
// 3 1 1 1
// 3 1 1 1
//
// -------------------------
module f5_2 ( output s,
 input a,
 input b );
// definir dado local
 wire not_b;
 wire inverter;
// descrever por portas
 nor NOR1 ( not_b, b, b);
 nor NOR2 ( inverter, not_b, a );
 nor NOR3 ( s, inverter, inverter );
endmodule // f5_2
