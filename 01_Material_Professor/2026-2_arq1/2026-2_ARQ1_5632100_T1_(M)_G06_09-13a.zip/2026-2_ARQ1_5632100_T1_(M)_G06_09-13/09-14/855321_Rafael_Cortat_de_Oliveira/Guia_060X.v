/*
Guia_06.v
678019 - Rafael Cortat De Oliveira
*/

// ============================================================================
// --- EXERCISE 1 (3 variables: x, y, z) --------------------------------------
// ============================================================================
// a.)

// a.) f(x,y,z) = ∑ m( 1, 6, 7 )
module E1a_simp (output s, input x, input y, input z); assign s = (x & y) | (~x & ~y & z); endmodule
module E1a_non  (output s, input x, input y, input z); assign s = (~x & ~y & z) | (x & y & ~z) | (x & y & z); endmodule
// b.) f(x,y,z) = ∑ m( 0, 2, 6 )
module E1b_simp (output s, input x, input y, input z); assign s = ~z & (y|~x); endmodule
module E1b_non  (output s, input x, input y, input z); assign s = (~x & ~y & ~z) | (~x & y & ~z) | (x & y & ~z); endmodule
// c.) f(x,y,z) = ∑ m( 1, 3, 6, 7 )
module E1c_simp (output s, input x, input y, input z); assign s = (~x&z)|(x&y); endmodule
module E1c_non  (output s, input x, input y, input z); assign s = (~x & ~y & z) | (~x & y & z) | (x & y & ~z) | (x & y & z); endmodule
// d.) f(x,y,z) = ∑ m( 1, 2, 4, 6 )
module E1d_simp (output s, input x, input y, input z); assign s = (~z & (x | y)) | (~x & ~y & z); endmodule
module E1d_non  (output s, input x, input y, input z); assign s = (~x & ~y & z) | (~x & y & ~z) | (x & ~y & ~z) | (x & y & ~z); endmodule
// e.) f(x,y,z) = ∑ m( 0, 1, 5, 7 )
module E1e_simp (output s, input x, input y, input z); assign s = (~x&~y) | (x&z); endmodule
module E1e_non  (output s, input x, input y, input z); assign s = (~x & ~y & ~z) | (~x & ~y & z) | (x & ~y & z) | (x & y & z); endmodule

// ============================================================================
// --- EXERCISE 2 (3 variables: x, y, z) --------------------------------------
// ============================================================================
// a.)
// a.)
module E2a_simp (output s, input x, input y, input z); assign s = y|(~x&z); endmodule
module E2a_non  (output s, input x, input y, input z); assign s = (x|y|z) & (~x|y|z) & (~x|y|~z); endmodule
// b.)
module E2b_simp (output s, input x, input y, input z); assign s = y |(x&~z); endmodule
module E2b_non  (output s, input x, input y, input z); assign s =  (x|y|z) & (x|y|~z) & (~x|y|~z); endmodule
// c.)
module E2c_simp (output s, input x, input y, input z); assign s = (x|~z) & (~y|z); endmodule
module E2c_non  (output s, input x, input y, input z); assign s = (x|y|~z) & (x|~y|z) & (x|~y|~z) & (~x|~y|z); endmodule
// d.)
module E2d_simp (output s, input x, input y, input z); assign s = 1'b0; endmodule
module E2d_non  (output s, input x, input y, input z); assign s = (x|y|z) & (x|y|~z) & (x|~y|~z) & (~x|y|~z); endmodule
// e.)
module E2e_simp (output s, input x, input y, input z); assign s = 1'b0; endmodule
module E2e_non  (output s, input x, input y, input z); assign s = (x|y|z) & (x|y|~z) & (~x|~y|z) & (~x|~y|~z); endmodule

// ============================================================================
// --- EXERCISE 3 (4 variables: x, y, w, z) -----------------------------------
// ============================================================================
// a.)
module E3a_simp (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
module E3a_non  (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
// b.)
module E3b_simp (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
module E3b_non  (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
// c.)
module E3c_simp (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
module E3c_non  (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
// d.)
module E3d_simp (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
module E3d_non  (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
// e.)
module E3e_simp (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
module E3e_non  (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule

// ============================================================================
// --- EXERCISE 4 (4 variables: x, y, w, z) -----------------------------------
// ============================================================================
// a.)
module E4a_simp (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
module E4a_non  (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
// b.)
module E4b_simp (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
module E4b_non  (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
// c.)
module E4c_simp (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
module E4c_non  (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
// d.)
module E4d_simp (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
module E4d_non  (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
// e.)
module E4e_simp (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
module E4e_non  (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule

// ============================================================================
// --- EXERCISE 5 (3 variables: x, y, z) --------------------------------------
// ============================================================================
module E5_orig (output s, input x, input y, input z); assign s = 1'b0; endmodule
module E5_simp (output s, input x, input y, input z); assign s = 1'b0; endmodule

// ============================================================================
// --- EXERCISE 6 (4 variables: x, y, w, z) -----------------------------------
// ============================================================================
module E6_orig (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule
module E6_simp (output s, input x, input y, input w, input z); assign s = 1'b0; endmodule


// ============================================================================
// --- MAIN TESTBENCH ---------------------------------------------------------
// ============================================================================
module Guia_06_Test;
    reg x, y, w, z;

    // --- Wires for 3 variables (Ex 1, 2, 5) ---
    wire s1aS, s1aN, s1bS, s1bN, s1cS, s1cN, s1dS, s1dN, s1eS, s1eN;
    wire s2aS, s2aN, s2bS, s2bN, s2cS, s2cN, s2dS, s2dN, s2eS, s2eN;
    wire s5O,  s5S;

    // --- Wires for 4 variables (Ex 3, 4, 6) ---
    wire s3aS, s3aN, s3bS, s3bN, s3cS, s3cN, s3dS, s3dN, s3eS, s3eN;
    wire s4aS, s4aN, s4bS, s4bN, s4cS, s4cN, s4dS, s4dN, s4eS, s4eN;
    wire s6O,  s6S;

    // --- Instances (Ex 1) ---
    E1a_simp e1aS(s1aS, x, y, z); E1a_non e1aN(s1aN, x, y, z);
    E1b_simp e1bS(s1bS, x, y, z); E1b_non e1bN(s1bN, x, y, z);
    E1c_simp e1cS(s1cS, x, y, z); E1c_non e1cN(s1cN, x, y, z);
    E1d_simp e1dS(s1dS, x, y, z); E1d_non e1dN(s1dN, x, y, z);
    E1e_simp e1eS(s1eS, x, y, z); E1e_non e1eN(s1eN, x, y, z);

    // --- Instances (Ex 2) ---
    E2a_simp e2aS(s2aS, x, y, z); E2a_non e2aN(s2aN, x, y, z);
    E2b_simp e2bS(s2bS, x, y, z); E2b_non e2bN(s2bN, x, y, z);
    E2c_simp e2cS(s2cS, x, y, z); E2c_non e2cN(s2cN, x, y, z);
    E2d_simp e2dS(s2dS, x, y, z); E2d_non e2dN(s2dN, x, y, z);
    E2e_simp e2eS(s2eS, x, y, z); E2e_non e2eN(s2eN, x, y, z);

    // --- Instances (Ex 3) ---
    E3a_simp e3aS(s3aS, x, y, w, z); E3a_non e3aN(s3aN, x, y, w, z);
    E3b_simp e3bS(s3bS, x, y, w, z); E3b_non e3bN(s3bN, x, y, w, z);
    E3c_simp e3cS(s3cS, x, y, w, z); E3c_non e3cN(s3cN, x, y, w, z);
    E3d_simp e3dS(s3dS, x, y, w, z); E3d_non e3dN(s3dN, x, y, w, z);
    E3e_simp e3eS(s3eS, x, y, w, z); E3e_non e3eN(s3eN, x, y, w, z);

    // --- Instances (Ex 4) ---
    E4a_simp e4aS(s4aS, x, y, w, z); E4a_non e4aN(s4aN, x, y, w, z);
    E4b_simp e4bS(s4bS, x, y, w, z); E4b_non e4bN(s4bN, x, y, w, z);
    E4c_simp e4cS(s4cS, x, y, w, z); E4c_non e4cN(s4cN, x, y, w, z);
    E4d_simp e4dS(s4dS, x, y, w, z); E4d_non e4dN(s4dN, x, y, w, z);
    E4e_simp e4eS(s4eS, x, y, w, z); E4e_non e4eN(s4eN, x, y, w, z);

    // --- Instances (Ex 5 & 6) ---
    E5_orig e5O(s5O, x, y, z); E5_simp e5S(s5S, x, y, z);
    E6_orig e6O(s6O, x, y, w, z); E6_simp e6S(s6S, x, y, w, z);

    initial begin
        x=0; y=0; w=0; z=0;
        $display("Guia_06 - Rafael Cortat De Oliveira - 678019");

        // --------------------------------------------------------------------
        // TEST BLOCK 1: 3-Variable Functions
        // --------------------------------------------------------------------
        $display("\n=========================================================================================================");
        $display(" PART 1: 3-Variable Tests (Exercises 1, 2, and 5)");
        $display("=========================================================================================================");
        $display(" x y z |  1a   |  1b   |  1c   |  1d   |  1e   ||  2a   |  2b   |  2c   |  2d   |  2e   ||   5   ");
        $display("       | S   N | S   N | S   N | S   N | S   N || S   N | S   N | S   N | S   N | S   N || O   S ");
        $display("-------+-------+-------+-------+-------+-------++-------+-------+-------+-------+-------++-------");
        
        $monitor(" %b %b %b | %b   %b | %b   %b | %b   %b | %b   %b | %b   %b || %b   %b | %b   %b | %b   %b | %b   %b | %b   %b || %b   %b ", 
                 x, y, z, 
                 s1aS, s1aN, s1bS, s1bN, s1cS, s1cN, s1dS, s1dN, s1eS, s1eN,
                 s2aS, s2aN, s2bS, s2bN, s2cS, s2cN, s2dS, s2dN, s2eS, s2eN,
                 s5O, s5S);

        #1 x=0; y=0; z=0;
        #1 x=0; y=0; z=1;
        #1 x=0; y=1; z=0;
        #1 x=0; y=1; z=1;
        #1 x=1; y=0; z=0;
        #1 x=1; y=0; z=1;
        #1 x=1; y=1; z=0;
        #1 x=1; y=1; z=1;

        #1 $monitoroff; // Turn off the first monitor so they don't overlap

        // --------------------------------------------------------------------
        // TEST BLOCK 2: 4-Variable Functions
        // --------------------------------------------------------------------
        $display("\n=========================================================================================================");
        $display(" PART 2: 4-Variable Tests (Exercises 3, 4, and 6)");
        $display("=========================================================================================================");
        $display(" x y w z |  3a   |  3b   |  3c   |  3d   |  3e   ||  4a   |  4b   |  4c   |  4d   |  4e   ||   6   ");
        $display("         | S   N | S   N | S   N | S   N | S   N || S   N | S   N | S   N | S   N | S   N || O   S ");
        $display("---------+-------+-------+-------+-------+-------++-------+-------+-------+-------+-------++-------");
        
        $monitor(" %b %b %b %b | %b   %b | %b   %b | %b   %b | %b   %b | %b   %b || %b   %b | %b   %b | %b   %b | %b   %b | %b   %b || %b   %b ", 
                 x, y, w, z, 
                 s3aS, s3aN, s3bS, s3bN, s3cS, s3cN, s3dS, s3dN, s3eS, s3eN,
                 s4aS, s4aN, s4bS, s4bN, s4cS, s4cN, s4dS, s4dN, s4eS, s4eN,
                 s6O, s6S);

        #1 x=0; y=0; w=0; z=0;
        #1 x=0; y=0; w=0; z=1;
        #1 x=0; y=0; w=1; z=0;
        #1 x=0; y=0; w=1; z=1;
        #1 x=0; y=1; w=0; z=0;
        #1 x=0; y=1; w=0; z=1;
        #1 x=0; y=1; w=1; z=0;
        #1 x=0; y=1; w=1; z=1;
        #1 x=1; y=0; w=0; z=0;
        #1 x=1; y=0; w=0; z=1;
        #1 x=1; y=0; w=1; z=0;
        #1 x=1; y=0; w=1; z=1;
        #1 x=1; y=1; w=0; z=0;
        #1 x=1; y=1; w=0; z=1;
        #1 x=1; y=1; w=1; z=0;
        #1 x=1; y=1; w=1; z=1;
    end
endmodule