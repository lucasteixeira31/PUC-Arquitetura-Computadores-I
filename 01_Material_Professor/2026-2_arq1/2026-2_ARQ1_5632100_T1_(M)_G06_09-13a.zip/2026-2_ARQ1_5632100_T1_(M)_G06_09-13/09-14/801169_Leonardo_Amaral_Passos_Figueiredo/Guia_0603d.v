/*
 Guia_0603d.v
 801169 - Leonardo Amaral

 Funcao:
 f(x,y,w,z) = Σm(2,3,5,7,11,12,15)

 Funcao simplificada:
 f = wz + x'yz + xw'y' + xyw'z'
*/

module Guia_0603d(
    output f,
    input x,
    input y,
    input w,
    input z
);

assign f = (w & z) |
           (~x & y & z) |
           (x & ~w & ~y) |
           (x & y & ~w & ~z);

endmodule