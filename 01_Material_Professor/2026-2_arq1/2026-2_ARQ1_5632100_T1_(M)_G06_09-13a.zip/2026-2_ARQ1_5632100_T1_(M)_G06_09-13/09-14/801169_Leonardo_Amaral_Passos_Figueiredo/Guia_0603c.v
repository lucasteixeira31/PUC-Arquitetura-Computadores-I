/*
 Guia_0603c.v
 801169 - Leonardo Amaral

 Funcao:
 f(x,y,w,z) = Σm(0,1,2,7,10,11,13,15)

 Funcao simplificada:
 f = ywz + xyz + xy'w + xw'z' + x'y'w'
*/

module Guia_0603c(
    output f,
    input x,
    input y,
    input w,
    input z
);

assign f = (y & w & z) |
           (x & y & z) |
           (x & ~y & w) |
           (x & ~w & ~z) |
           (~x & ~y & ~w);

endmodule