/*
 Guia_0601c.v
 801169 - Leonardo Amaral

 f(x,y,z) = Σm(1,3,6,7)

 Funcao simplificada:
 f = x'.z + x.y
*/

module Guia_0601c(
    output f,
    input x,
    input y,
    input z
);

assign f = (~x & z) | (x & y);

endmodule