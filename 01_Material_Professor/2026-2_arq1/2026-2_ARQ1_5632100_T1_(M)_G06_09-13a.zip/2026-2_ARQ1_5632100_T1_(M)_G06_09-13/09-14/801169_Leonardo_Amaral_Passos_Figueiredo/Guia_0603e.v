/*
 Guia_0603e.v
 801169 - Leonardo Amaral

 Funcao:
 f(x,y,w,z) = Σm(0,1,3,5,7,8,11,13)

 Funcao simplificada:
 f = x'z + yw'z + y'wz + x'w'z'
*/

module Guia_0603e(
    output f,
    input x,
    input y,
    input w,
    input z
);

assign f = (~x & z) |
           (y & ~w & z) |
           (~y & w & z) |
           (~x & ~w & ~z);

endmodule