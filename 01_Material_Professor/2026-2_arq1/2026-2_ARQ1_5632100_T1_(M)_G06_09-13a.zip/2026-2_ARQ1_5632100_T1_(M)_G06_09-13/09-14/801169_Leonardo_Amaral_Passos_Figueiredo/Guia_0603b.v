/*
 Guia_0603b
 801169 - Leonardo Amaral

 Funcao:
 f(x,y,w,z) = Σm(0,1,3,5,9,13,15)

 Funcao simplificada:
 f = w'z + x'y'w' + x'y'z + xyz
*/

module Guia_0603b(
    output f,
    input x,
    input y,
    input w,
    input z
);

assign f = (~w & z) |
           (~x & ~y & ~w) |
           (~x & ~y & z) |
           (x & y & z);

endmodule