/*
 Guia_0604c.v
 801169 - Leonardo Amaral

 Funcao:
 F(X,Y,W,Z) = pi M(4,6,8,14,15)

 Funcao simplificada:
 F = (X+Y'+Z)(X'+Y+Z+W)(X'+Y'+W')
*/

module Guia_0604c(
    output f,
    input x,
    input y,
    input w,
    input z
);

assign f = (x | ~y | z) &
           (~x | y | z | w) &
           (~x | ~y | ~w);

endmodule