/*
 Guia_0603a.v
 801169 - Leonardo Amaral

 Funcao:
 f(x,y,w,z) = Σm(1,2,5,8,12,13)

 Funcao simplificada:
 f = x'w'z + x'y'z + xw'z' + xyw'
*/

module Guia_0603a(
    output f,
    input x,
    input y,
    input w,
    input z
);

assign f = (~x & ~w & z) |
           (~x & ~y & z) |
           (x & ~w & ~z) |
           (x & y & ~w);

endmodule