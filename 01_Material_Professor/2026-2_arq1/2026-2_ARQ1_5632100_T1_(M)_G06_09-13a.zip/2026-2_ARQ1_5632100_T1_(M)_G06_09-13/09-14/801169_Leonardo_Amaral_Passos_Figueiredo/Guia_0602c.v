/*
 Guia_0602c.v
 801169 - Leonardo Amaral

 f(X,Y,Z) = π M ( 1, 2, 3, 6 )  

 Funcao simplificada:
 f = (x | ~z) & (~y | z) & (x | ~y)
*/
module Guia_0602c(
    output f,
    input x,
    input y,
    input z
);

assign f = (x | ~z) & (~y | z) & (x | ~y);

endmodule