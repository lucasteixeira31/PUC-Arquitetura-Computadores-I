/*
 Guia_0602b.v
 801169 - Leonardo Amaral

 f(X,Y,Z) = π M ( 0, 1, 5 ) 

 Funcao simplificada:
 f = (x | y) & (y | ~z)
*/
module Guia_0602b(
    output f,
    input x,
    input y,
    input z
);

assign f = (x | y) & (y | ~z);

endmodule