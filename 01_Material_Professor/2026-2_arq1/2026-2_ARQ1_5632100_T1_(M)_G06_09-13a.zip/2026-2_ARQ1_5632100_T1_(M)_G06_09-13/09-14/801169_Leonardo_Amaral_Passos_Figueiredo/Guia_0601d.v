/*
 Guia_0601d.v
 801169 - Leonardo Amaral

 f(x,y,z) = Σm(1,2,4,6)

 Funcao simplificada:
 f = y.z' + x.z' + x'.y'.z
*/

module Guia_0601d(
    output f,
    input x,
    input y,
    input z
);

assign f = (y & ~z) | (x & ~z) | (~x & ~y & z);

endmodule