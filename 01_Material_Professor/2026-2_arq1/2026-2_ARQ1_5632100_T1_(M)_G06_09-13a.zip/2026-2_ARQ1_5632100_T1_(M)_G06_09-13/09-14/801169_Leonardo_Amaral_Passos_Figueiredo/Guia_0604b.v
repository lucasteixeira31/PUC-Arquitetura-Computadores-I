/*
 Guia_0604b.v
 801169 - Leonardo Amaral

 Funcao:
 F(X,Y,W,Z) = pi M(4,7,9,13,15)

 Funcao simplificada:
 F = (X'+W+Z')(Y'+W'+Z')(X+Y'+W+Z)
*/

module Guia_0604b(
    output f,
    input x,
    input y,
    input w,
    input z
);

assign f = (~x | w | ~z) &
           (~y | ~w | ~z) &
           (x | ~y | w | z);

endmodule