/*
 Guia_0601b.v
 801169 - Leonardo Amaral

 f(x,y,z) = Σm(0,2,6)

 Funcao simplificada:
 f = x'.z' + y.z'
*/

module Guia_0601b(
    output f,
    input x,
    input y,
    input z
);

assign f = (~x & ~z) | (y & ~z);

endmodule