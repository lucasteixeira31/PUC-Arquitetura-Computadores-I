/*
 Guia_0604e.v
 801169 - Leonardo Amaral

 Funcao:
 F(X,Y,W,Z) = pi M(2,3,4,6,11,12,14)

 Funcao simplificada:
 F = (Y'+Z)(X+Y+W')(Y+W'+Z')
*/

module Guia_0604e(
    output f,
    input x,
    input y,
    input w,
    input z
);

assign f = (~y | z) &
           (x | y | ~w) &
           (y | ~w | ~z);

endmodule