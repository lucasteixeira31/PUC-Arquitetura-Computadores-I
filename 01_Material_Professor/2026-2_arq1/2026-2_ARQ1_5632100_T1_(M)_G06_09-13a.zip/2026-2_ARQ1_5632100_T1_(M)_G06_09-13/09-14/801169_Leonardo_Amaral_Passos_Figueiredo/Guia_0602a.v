/*
 Guia_0602a.v
 801169 - Leonardo Amaral

 f(X,Y,Z) = π M ( 0, 4, 5 )

 Funcao simplificada:
 f = (y | z) & (~x | y)
*/
module Guia_0602a(
    output f,
    input x,
    input y,
    input z
);

assign f = (y | z) & (~x | y);

endmodule