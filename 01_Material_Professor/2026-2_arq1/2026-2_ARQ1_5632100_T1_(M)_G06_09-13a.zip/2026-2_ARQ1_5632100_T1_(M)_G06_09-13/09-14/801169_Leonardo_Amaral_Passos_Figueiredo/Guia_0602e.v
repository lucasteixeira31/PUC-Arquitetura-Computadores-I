/*
 Guia_0602e.v
 801169 - Leonardo Amaral

 f(X,Y,Z) = π M ( 0, 1, 6, 7 )    

 Funcao simplificada:
 f = (x | y) & (~x | ~y)
*/

module Guia_0602e(
    output f,
    input x,
    input y,
    input z
);

assign f = (x | y) & (~x | ~y);

endmodule