/*
 Guia_0601a.v
 801169 - Leonardo Amaral

 f(x,y,z) = Σm(1,6,7)

 Funcao simplificada:
 f = x.y + x'.y'.z
*/

module Guia_0601a(
    output f,
    input x,
    input y,
    input z
);

wire nx;

not n1(nx, x);

and a1(t1, x, y);
and a2(t2, nx, y, ~z);

or o1(f, t1, t2);

endmodule