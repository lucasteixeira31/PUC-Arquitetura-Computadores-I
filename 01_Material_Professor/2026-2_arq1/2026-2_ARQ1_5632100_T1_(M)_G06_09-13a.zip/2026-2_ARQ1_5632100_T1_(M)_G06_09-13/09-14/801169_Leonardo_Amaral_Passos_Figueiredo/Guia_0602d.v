/*
 Guia_0602d.v
 801169 - Leonardo Amaral

 f(X,Y,Z) = π M ( 0, 1, 3, 5)   

 Funcao simplificada:
 f = (x | y) & (x | ~z) & (y | ~z)
*/
module Guia_0602d(
    output f,
    input x,
    input y,
    input z
);

assign f = (x | y) & (x | ~z) & (y | ~z);

endmodule