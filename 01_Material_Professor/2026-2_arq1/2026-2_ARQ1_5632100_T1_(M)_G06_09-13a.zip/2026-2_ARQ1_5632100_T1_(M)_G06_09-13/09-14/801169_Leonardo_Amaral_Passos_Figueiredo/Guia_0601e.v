/*
 Guia_0601e.v
 801169 - Leonardo Amaral

 f(x,y,z) = Σm(0,1,5,7)

 Funcao simplificada:
 f = x'.y' + x.z
*/

module Guia_0601e(
    output f,
    input x,
    input y,
    input z
);

assign f = (~x & ~y) | (x & z);

endmodule