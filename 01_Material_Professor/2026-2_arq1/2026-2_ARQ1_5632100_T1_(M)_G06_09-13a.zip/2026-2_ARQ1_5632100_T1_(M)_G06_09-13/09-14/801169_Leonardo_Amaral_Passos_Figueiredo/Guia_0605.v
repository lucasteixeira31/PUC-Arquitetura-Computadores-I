/*
 Guia_0605v
 801169 - Leonardo Amaral

 S(X,Y,Z) = Sigma m(4,5,6)

 Funcao simplificada:
 S = XY' + XZ'
*/

module Guia_0605(
    output s,
    input x,
    input y,
    input z
);

assign s = (x & ~y) |
           (x & ~z);

endmodule