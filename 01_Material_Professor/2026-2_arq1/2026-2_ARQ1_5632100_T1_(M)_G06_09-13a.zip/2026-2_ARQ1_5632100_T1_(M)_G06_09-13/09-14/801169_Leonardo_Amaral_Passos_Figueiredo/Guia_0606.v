/*
 Guia_0606.v
 801169 - Leonardo Amaral

 Funcao original do circuito:
 S = w1 + w2

 Funcao simplificada:
 S = XY' + XW'
 S = X(Y' + W')

 Mintermos:
 S(X,Y,W,Z) = Sigma m(8,9,10,11,12,13)

 Maxtermos:
 S(X,Y,W,Z) = Pi M(0,1,2,3,4,5,6,7,14,15)
*/

module Guia_0606(
    output s,
    input x,
    input y,
    input w,
    input z
);

assign s = (x & ~y) |
           (x & ~w);

endmodule