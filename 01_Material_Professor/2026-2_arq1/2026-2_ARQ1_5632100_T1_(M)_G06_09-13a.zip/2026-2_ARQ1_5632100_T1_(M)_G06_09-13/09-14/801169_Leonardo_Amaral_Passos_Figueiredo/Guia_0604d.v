/*
 Guia_0604d.v
 801169 - Leonardo Amaral

 Funcao:
 F(X,Y,W,Z) = pi M(1,5,7,12,13,15)

 Funcao simplificada:
 F = (X+W+Z')(X'+Y'+Z')(Y'+Z')
*/

module Guia_0604d(
    output f,
    input x,
    input y,
    input w,
    input z
);

assign f = (x | w | ~z) &
           (~x | ~y | ~z) &
           (~y | ~z);

endmodule