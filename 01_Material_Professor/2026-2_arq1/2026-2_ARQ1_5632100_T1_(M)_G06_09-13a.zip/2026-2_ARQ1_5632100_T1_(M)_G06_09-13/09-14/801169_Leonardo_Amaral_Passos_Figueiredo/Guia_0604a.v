/*
 Guia_0604a.v
 801169 - Leonardo Amaral

 Funcao:
 F(X,Y,W,Z) = pi M(2,6,7,14)

 Funcao simplificada:
 F = (X+Z+W')(X+Y'+W')(Y'+Z+W')
*/

module Guia_0604a(
    output f,
    input x,
    input y,
    input w,
    input z
);

assign f = (x | z | ~w) &
           (x | ~y | ~w) &
           (~y | z | ~w);

endmodule