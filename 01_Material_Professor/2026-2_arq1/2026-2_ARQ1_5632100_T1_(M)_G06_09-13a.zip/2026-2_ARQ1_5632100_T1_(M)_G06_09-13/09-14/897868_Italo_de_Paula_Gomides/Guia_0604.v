// Guia_0604.v - exercicio 04: simplificacao por maxtermos / PoS (4 variaveis)

// a) F = prod M(2,6,7,14)  ->  simplificado: (X+W'+Z)(X+Y'+W')(Y'+W'+Z)
module f04a (output s, input x, input y, input w, input z);
    assign s = (x | ~w | z) & (x | ~y | ~w) & (~y | ~w | z);
endmodule

// b) F = prod M(4,7,9,13,15)  ->  simplificado: (X+Y'+W+Z)(Y'+W'+Z')(X'+W+Z')
module f04b (output s, input x, input y, input w, input z);
    assign s = (x | ~y | w | z) & (~y | ~w | ~z) & (~x | w | ~z);
endmodule

// c) F = prod M(4,6,8,14,15)  ->  simplificado: (X'+Y+W+Z)(X+Y'+Z)(X'+Y'+W')
module f04c (output s, input x, input y, input w, input z);
    assign s = (~x | y | w | z) & (x | ~y | z) & (~x | ~y | ~w);
endmodule

// d) F = prod M(1,5,7,12,13,15)  ->  simplificado: (X+W+Z')(X'+Y'+W)(Y'+Z')
module f04d (output s, input x, input y, input w, input z);
    assign s = (x | w | ~z) & (~x | ~y | w) & (~y | ~z);
endmodule

// e) F = prod M(2,3,4,6,11,12,14)  ->  simplificado: (Y'+Z)(Y+W'+Z')(X+Y+W')
module f04e (output s, input x, input y, input w, input z);
    assign s = (~y | z) & (y | ~w | ~z) & (x | y | ~w);
endmodule


module test_guia_0604;
    reg x, y, w, z;
    wire sa, sb, sc, sd, se;
    integer i;

    f04a uut_a (sa, x, y, w, z);
    f04b uut_b (sb, x, y, w, z);
    f04c uut_c (sc, x, y, w, z);
    f04d uut_d (sd, x, y, w, z);
    f04e uut_e (se, x, y, w, z);

    initial begin
        $display("Guia_0604 - x y w z | a b c d e");
        for (i = 0; i < 16; i = i + 1) begin
            {x, y, w, z} = i[3:0];
            #1 $display("      %b %b %b %b | %b %b %b %b %b", x, y, w, z, sa, sb, sc, sd, se);
        end
    end
endmodule
