// Guia_0607.v - extra 07: expressao dada no guia e sua forma simplificada
// (X|~Y|Z)(X|Y|Z) simplifica pra (X+Z) [exemplo que ja vem no proprio guia],
// sobrando so multiplicar por (~X|~Y|~Z):
// s1 = (X+Z) . (X'+Y'+Z')

module FXYZ_original (output s1, input X, input Y, input Z);
    assign s1 = ( X | ~Y | Z ) & (X | Y | Z) & ( ~X | ~Y | ~Z );
endmodule // FXYZ

module FXYZ_simplificado (output s1, input X, input Y, input Z);
    assign s1 = (X | Z) & (~X | ~Y | ~Z);
endmodule


module test_guia_0607;
    reg X, Y, Z;
    wire s_orig, s_simp;
    integer i;

    FXYZ_original       uut_orig (s_orig, X, Y, Z);
    FXYZ_simplificado    uut_simp (s_simp, X, Y, Z);

    initial begin
        $display("Guia_0607 - X Y Z | original simplificado");
        for (i = 0; i < 8; i = i + 1) begin
            {X, Y, Z} = i[2:0];
            #1 $display("      %b %b %b |    %b          %b", X, Y, Z, s_orig, s_simp);
        end
    end
endmodule
