// Guia_0608.v - extra 08: expressao dada no guia e sua forma simplificada
// os termos 1 e 3 sao iguais, e os termos 2 e 4 tambem sao iguais (repetidos),
// entao sobra so: (w.x.y.z') + (w'.x.y.z) = x.y.(w xor z)
// s1 = x & y & (w ^ z)

module fwxyz_original (output s1, input w, input x, input y, input z);
    assign s1 = (w & x & y & ~z) | (~w & x & y & z) | (w & x & y & ~z) | (~w & x & y & z);
endmodule // fwxyz

module fwxyz_simplificado (output s1, input w, input x, input y, input z);
    assign s1 = x & y & (w ^ z);
endmodule


module test_guia_0608;
    reg w, x, y, z;
    wire s_orig, s_simp;
    integer i;

    fwxyz_original       uut_orig (s_orig, w, x, y, z);
    fwxyz_simplificado    uut_simp (s_simp, w, x, y, z);

    initial begin
        $display("Guia_0608 - w x y z | original simplificado");
        for (i = 0; i < 16; i = i + 1) begin
            {w, x, y, z} = i[3:0];
            #1 $display("      %b %b %b %b |    %b          %b", w, x, y, z, s_orig, s_simp);
        end
    end
endmodule
