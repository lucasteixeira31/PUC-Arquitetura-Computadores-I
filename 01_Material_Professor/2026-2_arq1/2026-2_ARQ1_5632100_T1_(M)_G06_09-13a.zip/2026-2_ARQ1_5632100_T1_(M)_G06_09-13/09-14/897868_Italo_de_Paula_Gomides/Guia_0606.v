// Guia_0606.v - exercicio 06: circuito dado (x,y,w,z) e sua forma simplificada
// Equacao tirada porta por porta do desenho (w1..w12), depois simplificada
// pelo mapa usando maxtermos: s = X . (Y'+W'+Z') = x & ~(y & w & z)

module f06_original (output s, input x, input y, input w, input z);
    wire w8, w9, w5, w3, w6, w10, w4, w1;
    wire w11, w12, w7, w2;

    not  (w8, y);
    not  (w9, x);
    or   (w5, w8, w, w9);     // porta OR de 3 entradas
    not  (w3, w5);
    not  (w10, w);
    and  (w6, y, w10, x);     // porta AND de 3 entradas
    not  (w4, w6);
    and  (w1, w3, w4);        // essa ponta sempre da 0 (mesma pegadinha do exercicio 05)

    and  (w11, z, w, y);      // porta AND de 3 entradas
    not  (w12, x);
    or   (w7, w11, w12);
    not  (w2, w7);

    or   (s, w1, w2);
endmodule

// versao simplificada: s = X . (Y'+W'+Z')
module f06_simplificado (output s, input x, input y, input w, input z);
    assign s = x & (~y | ~w | ~z);
endmodule


module test_guia_0606;
    reg x, y, w, z;
    wire s_orig, s_simp;
    integer i;

    f06_original      uut_orig (s_orig, x, y, w, z);
    f06_simplificado   uut_simp (s_simp, x, y, w, z);

    initial begin
        $display("Guia_0606 - x y w z | original simplificado");
        for (i = 0; i < 16; i = i + 1) begin
            {x, y, w, z} = i[3:0];
            #1 $display("      %b %b %b %b |    %b          %b", x, y, w, z, s_orig, s_simp);
        end
    end
endmodule
