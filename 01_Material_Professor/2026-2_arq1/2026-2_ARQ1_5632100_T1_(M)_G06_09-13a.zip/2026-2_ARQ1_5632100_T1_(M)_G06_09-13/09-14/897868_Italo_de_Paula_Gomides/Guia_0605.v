// Guia_0605.v - exercicio 05: circuito dado (x,y,z) e sua forma simplificada
// Equacao tirada porta por porta do desenho (w1..w11), depois simplificada
// pelo mapa usando mintermos: s = som m(4,5,6) = xy' + xz' = x.(y'+z')

module f05_original (output s, input x, input y, input z);
    wire w8, w9, w5, w3, w6, w4, w1;
    wire w10, w11, w7, w2;

    not  (w8, y);
    not  (w9, x);
    or   (w5, w8, w9);
    not  (w3, w5);
    and  (w6, x, y);
    not  (w4, w6);
    and  (w1, w3, w4);      // essa ponta sempre da 0 (e a "pegadinha" do circuito)

    and  (w10, y, z);
    not  (w11, x);
    or   (w7, w10, w11);
    not  (w2, w7);

    or   (s, w1, w2);
endmodule

// versao simplificada: s = x.(y'+z')
module f05_simplificado (output s, input x, input y, input z);
    assign s = x & (~y | ~z);
endmodule


module test_guia_0605;
    reg x, y, z;
    wire s_orig, s_simp;
    integer i;

    f05_original      uut_orig (s_orig, x, y, z);
    f05_simplificado   uut_simp (s_simp, x, y, z);

    initial begin
        $display("Guia_0605 - x y z | original simplificado");
        for (i = 0; i < 8; i = i + 1) begin
            {x, y, z} = i[2:0];
            #1 $display("      %b %b %b |    %b          %b", x, y, z, s_orig, s_simp);
        end
    end
endmodule
