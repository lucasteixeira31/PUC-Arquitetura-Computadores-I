// Guia_0602.v - exercicio 02: simplificacao por maxtermos / PoS (3 variaveis)

// a) F = prod M(0,4,5)  ->  simplificado: (X'+Y)(Y+Z)
module f02a (output s, input x, input y, input z);
    assign s = (~x | y) & (y | z);
endmodule

// b) F = prod M(0,1,5)  ->  simplificado: (X+Y)(Y+Z')
module f02b (output s, input x, input y, input z);
    assign s = (x | y) & (y | ~z);
endmodule

// c) F = prod M(1,2,3,6)  ->  simplificado: (X+Z')(Y'+Z)
module f02c (output s, input x, input y, input z);
    assign s = (x | ~z) & (~y | z);
endmodule

// d) F = prod M(0,1,3,5)  ->  simplificado: (X+Y)(X+Z')(Y+Z')
module f02d (output s, input x, input y, input z);
    assign s = (x | y) & (x | ~z) & (y | ~z);
endmodule

// e) F = prod M(0,1,6,7)  ->  simplificado: (X+Y)(X'+Y')
module f02e (output s, input x, input y, input z);
    assign s = (x | y) & (~x | ~y);
endmodule


module test_guia_0602;
    reg x, y, z;
    wire sa, sb, sc, sd, se;
    integer i;

    f02a uut_a (sa, x, y, z);
    f02b uut_b (sb, x, y, z);
    f02c uut_c (sc, x, y, z);
    f02d uut_d (sd, x, y, z);
    f02e uut_e (se, x, y, z);

    initial begin
        $display("Guia_0602 - x y z | a b c d e");
        for (i = 0; i < 8; i = i + 1) begin
            {x, y, z} = i[2:0];
            #1 $display("      %b %b %b | %b %b %b %b %b", x, y, z, sa, sb, sc, sd, se);
        end
    end
endmodule
