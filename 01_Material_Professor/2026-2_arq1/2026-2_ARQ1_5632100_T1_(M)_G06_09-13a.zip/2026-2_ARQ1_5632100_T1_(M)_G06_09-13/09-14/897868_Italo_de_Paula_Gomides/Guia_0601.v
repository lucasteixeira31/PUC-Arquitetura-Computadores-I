// Guia_0601.v - exercicio 01: simplificacao por mintermos (3 variaveis)

// a) f = som m(1,6,7)  ->  simplificado: xy + x'y'z
module f01a (output s, input x, input y, input z);
    assign s = (x & y) | (~x & ~y & z);
endmodule

// b) f = som m(0,2,6)  ->  simplificado: x'z' + yz'
module f01b (output s, input x, input y, input z);
    assign s = (~x & ~z) | (y & ~z);
endmodule

// c) f = som m(1,3,6,7)  ->  simplificado: x'z + xy
module f01c (output s, input x, input y, input z);
    assign s = (~x & z) | (x & y);
endmodule

// d) f = som m(1,2,4,6)  ->  simplificado: x'y'z + xz' + yz'
module f01d (output s, input x, input y, input z);
    assign s = (~x & ~y & z) | (x & ~z) | (y & ~z);
endmodule

// e) f = som m(0,1,5,7)  ->  simplificado: x'y' + xz
module f01e (output s, input x, input y, input z);
    assign s = (~x & ~y) | (x & z);
endmodule


module test_guia_0601;
    reg x, y, z;
    wire sa, sb, sc, sd, se;
    integer i;

    f01a uut_a (sa, x, y, z);
    f01b uut_b (sb, x, y, z);
    f01c uut_c (sc, x, y, z);
    f01d uut_d (sd, x, y, z);
    f01e uut_e (se, x, y, z);

    initial begin
        $display("Guia_0601 - x y z | a b c d e");
        for (i = 0; i < 8; i = i + 1) begin
            {x, y, z} = i[2:0];
            #1 $display("      %b %b %b | %b %b %b %b %b", x, y, z, sa, sb, sc, sd, se);
        end
    end
endmodule
