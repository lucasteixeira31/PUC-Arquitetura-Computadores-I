// Guia_0603.v - exercicio 03: simplificacao por mintermos (4 variaveis)

// a) f = som m(1,2,5,8,12,13)  ->  simplificado: x'w'z + xw'z' + x'y'wz' + xyw'
module f03a (output s, input x, input y, input w, input z);
    assign s = (~x & ~w & z) | (x & ~w & ~z) | (~x & ~y & w & ~z) | (x & y & ~w);
endmodule

// b) f = som m(0,1,3,5,9,13,15)  ->  simplificado: x'y'w' + x'y'z + w'z + xyz
module f03b (output s, input x, input y, input w, input z);
    assign s = (~x & ~y & ~w) | (~x & ~y & z) | (~w & z) | (x & y & z);
endmodule

// c) f = som m(0,1,2,7,10,11,13,15)  ->  simplificado: x'y'w' + x'y'z' + xy'w + ywz + xyz
module f03c (output s, input x, input y, input w, input z);
    assign s = (~x & ~y & ~w) | (~x & ~y & ~z) | (x & ~y & w) | (y & w & z) | (x & y & z);
endmodule

// d) f = som m(2,3,5,7,11,12,15)  ->  simplificado: x'y'w + x'yz + wz + xyw'z'
module f03d (output s, input x, input y, input w, input z);
    assign s = (~x & ~y & w) | (~x & y & z) | (w & z) | (x & y & ~w & ~z);
endmodule

// e) f = som m(0,1,3,5,7,8,11,13)  ->  simplificado: x'z + y'w'z' + y'wz + yw'z
module f03e (output s, input x, input y, input w, input z);
    assign s = (~x & z) | (~y & ~w & ~z) | (~y & w & z) | (y & ~w & z);
endmodule


module test_guia_0603;
    reg x, y, w, z;
    wire sa, sb, sc, sd, se;
    integer i;

    f03a uut_a (sa, x, y, w, z);
    f03b uut_b (sb, x, y, w, z);
    f03c uut_c (sc, x, y, w, z);
    f03d uut_d (sd, x, y, w, z);
    f03e uut_e (se, x, y, w, z);

    initial begin
        $display("Guia_0603 - x y w z | a b c d e");
        for (i = 0; i < 16; i = i + 1) begin
            {x, y, w, z} = i[3:0];
            #1 $display("      %b %b %b %b | %b %b %b %b %b", x, y, w, z, sa, sb, sc, sd, se);
        end
    end
endmodule
