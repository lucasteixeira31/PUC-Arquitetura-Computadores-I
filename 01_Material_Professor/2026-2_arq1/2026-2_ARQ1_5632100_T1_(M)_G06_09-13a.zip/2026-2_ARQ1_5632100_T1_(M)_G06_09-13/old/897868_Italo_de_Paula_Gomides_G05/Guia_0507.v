// Guia_0507.v - s = ~(a ^ b), usando somente portas NAND (extra)
module f5_07 ( output s,
               input a,
               input b );

    wire n1, n2, n3, n4;

    nand NAND1 ( n1, a, b );    // n1 = ~(a.b)
    nand NAND2 ( n2, a, n1 );   // n2 = ~(a.n1)
    nand NAND3 ( n3, b, n1 );   // n3 = ~(b.n1)
    nand NAND4 ( n4, n2, n3 );  // n4 = ~(n2.n3) = a xor b
    nand NAND5 ( s,  n4, n4 );  // s  = ~n4 = ~(a xor b)

endmodule // f5_07


module test_f5_07;
    reg x;
    reg y;
    wire s;

    f5_07 modulo ( s, x, y );

    initial
    begin : main
        $display("Guia_0507 - s = ~(a^b) (so com nand)");
        $display("  x y s");
        $monitor("%4b %4b %4b", x, y, s);
        x = 1'b0; y = 1'b0;
        #1 x = 1'b0; y = 1'b1;
        #1 x = 1'b1; y = 1'b0;
        #1 x = 1'b1; y = 1'b1;
    end
endmodule // test_f5_07
