// Guia_0502.v - s = a | ~b, usando somente portas NOR
module f5_02 ( output s,
               input a,
               input b );

    wire nb;   // ~b
    wire n1;   // ~(a | ~b), falta inverter

    nor NOR1 ( nb, b, b );    // inverte b
    nor NOR2 ( n1, a, nb );   // nor(a,nb) = ~(a | ~b)
    nor NOR3 ( s, n1, n1 );   // inverte de novo, sobra o OR

endmodule // f5_02


module test_f5_02;
    reg x;
    reg y;
    wire s;

    f5_02 modulo ( s, x, y );

    initial
    begin : main
        $display("Guia_0502 - s = a | ~b (so com nor)");
        $display("  x y s");
        $monitor("%4b %4b %4b", x, y, s);
        x = 1'b0; y = 1'b0;
        #1 x = 1'b0; y = 1'b1;
        #1 x = 1'b1; y = 1'b0;
        #1 x = 1'b1; y = 1'b1;
    end
endmodule // test_f5_02
