// Guia_0503.v - s = ~(a | ~b), usando somente portas NAND
module f5_03 ( output s,
               input a,
               input b );

    wire nb;    // ~b
    wire na;    // ~a
    wire nnb;   // ~(~b) = b de novo
    wire t;     // a | ~b, montado via nand-nand

    nand NAND1 ( nb, b, b );      // pega ~b
    nand NAND2 ( na, a, a );      // pega ~a
    nand NAND3 ( nnb, nb, nb );   // desfaz a negacao de nb
    nand NAND4 ( t, na, nnb );    // OR(a,~b) via nand
    nand NAND5 ( s, t, t );       // inverte tudo, fecha o ~(...)

endmodule // f5_03


module test_f5_03;
    reg x;
    reg y;
    wire s;

    f5_03 modulo ( s, x, y );

    initial
    begin : main
        $display("Guia_0503 - s = ~(a | ~b) (so com nand)");
        $display("  x y s");
        $monitor("%4b %4b %4b", x, y, s);
        x = 1'b0; y = 1'b0;
        #1 x = 1'b0; y = 1'b1;
        #1 x = 1'b1; y = 1'b0;
        #1 x = 1'b1; y = 1'b1;
    end
endmodule // test_f5_03
