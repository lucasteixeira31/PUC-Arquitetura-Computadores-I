// Guia_0506.v - s = ~(a ^ b), XNOR, usando somente portas NOR
module f5_06 ( output s,
               input a,
               input b );

    wire n1, n2, n3;

    nor NOR1 ( n1, a, b );    // n1 = ~(a+b)
    nor NOR2 ( n2, a, n1 );   // n2 = ~(a+n1)
    nor NOR3 ( n3, b, n1 );   // n3 = ~(b+n1)
    nor NOR4 ( s, n2, n3 );   // s  = ~(n2+n3) = a xnor b

endmodule // f5_06


module test_f5_06;
    reg x;
    reg y;
    wire s;

    f5_06 modulo ( s, x, y );

    initial
    begin : main
        $display("Guia_0506 - s = ~(a^b), XNOR (so com nor)");
        $display("  x y s");
        $monitor("%4b %4b %4b", x, y, s);
        x = 1'b0; y = 1'b0;
        #1 x = 1'b0; y = 1'b1;
        #1 x = 1'b1; y = 1'b0;
        #1 x = 1'b1; y = 1'b1;
    end
endmodule // test_f5_06
