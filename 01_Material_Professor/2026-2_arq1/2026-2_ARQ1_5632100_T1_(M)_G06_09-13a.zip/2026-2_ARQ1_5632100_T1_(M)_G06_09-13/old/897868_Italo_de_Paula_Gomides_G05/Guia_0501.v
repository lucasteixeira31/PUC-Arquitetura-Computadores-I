// Guia_0501.v - s = ~a & b, usando somente portas NAND
module f5_01 ( output s,
               input a,
               input b );

    wire na;   // ~a
    wire n1;   // ~(~a & b), ainda falta inverter

    nand NAND1 ( na, a, a );    // inverte a
    nand NAND2 ( n1, na, b );   // nand(na,b) = ~(~a & b)
    nand NAND3 ( s, n1, n1 );   // inverte de novo, sobra o AND

endmodule // f5_01


module test_f5_01;
    reg x;
    reg y;
    wire s;

    f5_01 modulo ( s, x, y );

    initial
    begin : main
        $display("Guia_0501 - s = ~a & b (so com nand)");
        $display("  x y s");
        $monitor("%4b %4b %4b", x, y, s);
        x = 1'b0; y = 1'b0;
        #1 x = 1'b0; y = 1'b1;
        #1 x = 1'b1; y = 1'b0;
        #1 x = 1'b1; y = 1'b1;
    end
endmodule // test_f5_01
