// Guia_0508.v - s = ~a | ~b, usando somente portas NOR (extra)
module f5_08 ( output s,
               input a,
               input b );

    wire na;   // ~a
    wire nb;   // ~b
    wire t;    // a & b, montado via nor-nor

    nor NOR1 ( na, a, a );    // pega ~a
    nor NOR2 ( nb, b, b );    // pega ~b
    nor NOR3 ( t, na, nb );   // AND(a,b) via nor
    nor NOR4 ( s, t, t );     // inverte, vira ~a | ~b

endmodule // f5_08


module test_f5_08;
    reg x;
    reg y;
    wire s;

    f5_08 modulo ( s, x, y );

    initial
    begin : main
        $display("Guia_0508 - s = ~a | ~b (so com nor)");
        $display("  x y s");
        $monitor("%4b %4b %4b", x, y, s);
        x = 1'b0; y = 1'b0;
        #1 x = 1'b0; y = 1'b1;
        #1 x = 1'b1; y = 1'b0;
        #1 x = 1'b1; y = 1'b1;
    end
endmodule // test_f5_08
