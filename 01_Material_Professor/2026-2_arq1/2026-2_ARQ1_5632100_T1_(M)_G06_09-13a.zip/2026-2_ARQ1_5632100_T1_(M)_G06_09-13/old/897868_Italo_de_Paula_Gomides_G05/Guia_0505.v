// Guia_0505.v - s = a ^ b (XOR), usando somente portas NAND
module f5_05 ( output s,
               input a,
               input b );

    wire n1, n2, n3;

    nand NAND1 ( n1, a, b );    // n1 = ~(a.b)
    nand NAND2 ( n2, a, n1 );   // n2 = ~(a.n1)
    nand NAND3 ( n3, b, n1 );   // n3 = ~(b.n1)
    nand NAND4 ( s, n2, n3 );   // s  = ~(n2.n3) = a xor b

endmodule // f5_05


module test_f5_05;
    reg x;
    reg y;
    wire s;

    f5_05 modulo ( s, x, y );

    initial
    begin : main
        $display("Guia_0505 - s = a ^ b, XOR (so com nand)");
        $display("  x y s");
        $monitor("%4b %4b %4b", x, y, s);
        x = 1'b0; y = 1'b0;
        #1 x = 1'b0; y = 1'b1;
        #1 x = 1'b1; y = 1'b0;
        #1 x = 1'b1; y = 1'b1;
    end
endmodule // test_f5_05
