// Guia_0504.v - s = ~(~a & b), usando somente portas NOR
module f5_04 ( output s,
               input a,
               input b );

    wire na;    // ~a
    wire nna;   // ~(~a) = a de novo
    wire nb;    // ~b
    wire t;     // ~a & b, montado via nor-nor

    nor NOR1 ( na, a, a );      // pega ~a
    nor NOR2 ( nna, na, na );   // desfaz a negacao, sobra "a"
    nor NOR3 ( nb, b, b );      // pega ~b
    nor NOR4 ( t, nna, nb );    // AND(~a,b) via nor
    nor NOR5 ( s, t, t );       // inverte tudo, fecha o ~(...)

endmodule // f5_04


module test_f5_04;
    reg x;
    reg y;
    wire s;

    f5_04 modulo ( s, x, y );

    initial
    begin : main
        $display("Guia_0504 - s = ~(~a & b) (so com nor)");
        $display("  x y s");
        $monitor("%4b %4b %4b", x, y, s);
        x = 1'b0; y = 1'b0;
        #1 x = 1'b0; y = 1'b1;
        #1 x = 1'b1; y = 1'b0;
        #1 x = 1'b1; y = 1'b1;
    end
endmodule // test_f5_04
