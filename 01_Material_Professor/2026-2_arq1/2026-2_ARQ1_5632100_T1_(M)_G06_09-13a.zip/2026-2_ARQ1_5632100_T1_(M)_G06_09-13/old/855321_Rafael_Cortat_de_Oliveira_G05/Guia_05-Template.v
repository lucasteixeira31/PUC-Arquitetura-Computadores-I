// -------------------------
// Guia_0501_template.v - GATES
// Nome: Rafael Cortat De Oliveira
// Matricula: 999999
// -------------------------

// =======================================================
// NAND VERSIONS OF LOGIC GATES
// =======================================================

module not_nand (output s, input a);
    nand NAND1 (s, a, a);
endmodule

module and_nand (output s, input a, input b);
    wire not_and;
    nand NAND1 (not_and, a, b);
    nand NAND2 (s, not_and, not_and);
endmodule

module or_nand (output s, input a, input b);
    wire not_a, not_b;
    nand NAND1 (not_a, a, a);
    nand NAND2 (not_b, b, b);
    nand NAND3 (s, not_a, not_b);
endmodule

module xor_nand (output s, input a, input b);
    wire nand_ab, nand_a, nand_b;
    nand NAND1 (nand_ab, a, b);
    nand NAND2 (nand_a, a, nand_ab);
    nand NAND3 (nand_b, b, nand_ab);
    nand NAND4 (s, nand_a, nand_b);
endmodule

module xnor_nand (output s, input a, input b);
    wire nand_ab, nand_a, nand_b, xor_out;
    nand NAND1 (nand_ab, a, b);
    nand NAND2 (nand_a, a, nand_ab);
    nand NAND3 (nand_b, b, nand_ab);
    nand NAND4 (xor_out, nand_a, nand_b);
    nand NAND5 (s, xor_out, xor_out);
endmodule

// =======================================================
// NOR VERSIONS OF LOGIC GATES
// =======================================================

module not_nor (output s, input a);
    nor NOR1 (s, a, a);
endmodule

module and_nor (output s, input a, input b);
    wire not_a, not_b;
    nor NOR1 (not_a, a, a);
    nor NOR2 (not_b, b, b);
    nor NOR3 (s, not_a, not_b);
endmodule

module or_nor (output s, input a, input b);
    wire not_or;
    nor NOR1 (not_or, a, b);
    nor NOR2 (s, not_or, not_or);
endmodule

module xnor_nor (output s, input a, input b);
    wire nor_ab, nor_a, nor_b;
    nor NOR1 (nor_ab, a, b);
    nor NOR2 (nor_a, a, nor_ab);
    nor NOR3 (nor_b, b, nor_ab);
    nor NOR4 (s, nor_a, nor_b);
endmodule

module xor_nor (output s, input a, input b);
    wire nor_ab, nor_a, nor_b, xnor_out;
    nor NOR1 (nor_ab, a, b);
    nor NOR2 (nor_a, a, nor_ab);
    nor NOR3 (nor_b, b, nor_ab);
    nor NOR4 (xnor_out, nor_a, nor_b);
    nor NOR5 (s, xnor_out, xnor_out);
endmodule

// =======================================================
// TEMPLATE MODULE
// =======================================================

module template_module (output s, input a, input b);
    // Your minterm logic here
    // Example: assign s = ~a & b;
    
endmodule

// =======================================================
// TEST MODULE FOR MINTERMS 0-3
// =======================================================

module test_template;
    // ------------------------- definir dados
    reg x, y;
    wire out;

    // Instantiate module
    template_module MOD (out, x, y);

    // ------------------------- parte principal
    initial
    begin : main
        $display("Guia_0501 - GATES Template - Rafael Cortat De Oliveira - 999999");
        $display("Test module for Minterms");
        $display(" x y | out");
        
        // projetar testes do modulo
        $monitor("%2b %2b | %3b", x, y, out);
        
        // Testing all minterms combinations
           x = 1'b0; y = 1'b0; // 0
        #1 x = 1'b0; y = 1'b1; // 1
        #1 x = 1'b1; y = 1'b0; // 2
        #1 x = 1'b1; y = 1'b1; // 3
    end
endmodule // test_template
