// -------------------------
// Guia_0503.v - GATES
// Nome: Rafael Cortat De Oliveira
// Matricula: 678019
// -------------------------



module original (output s, input a, input b);
    wire notB, orOut1;
	not not1 (notB, b);
	or or1 (orOut1, a, notB);
	not notFinal(s, orOut1);
endmodule
/* TEST
// m a b s
// 0 0 0 0
// 1 0 1 1
// 2 1 0 0
// 3 1 1 0
*/
module not_nand (output s, input a);
    nand NAND1 (s, a, a);
endmodule

module f53_nand (output s, input a, input b);
    wire notB, nandOrNot1, nandOrNot2, nandOrOut1;
    
    not_nand not1(notB, b);
    not_nand not2(nandOrNot1, a);
    not_nand not3(nandOrNot2, notB);
    nand nand1(nandOrOut1, nandOrNot1, nandOrNot2);
    not_nand not4(s, nandOrOut1);
endmodule

/* TEST
// m a b s
// 0 0 0 0
// 1 0 1 1
// 2 1 0 0
// 3 1 1 0
*/

// =======================================================
// TEST MODULE FOR MINTERMS 1-7
// =======================================================

module test_template;
    // ------------------------- definir dados
    reg x, y;
    wire out1, out2;

    original base (out1, x, y);
	f53_nand NANDtest (out2, x, y);

    // ------------------------- parte principal
    initial
    begin : main
        $display("Guia_0503 - GATES Template - Rafael Cortat De Oliveira - 999999");
        $display("Test module for Minterms");
        $display(" x y | out");
        
        // projetar testes do modulo
        $monitor("%2b %2b| %3b | %3b", x, y, out1, out2);
        
        // Testing all minterms combinations
           x = 1'b0; y = 1'b0; // 0
        #1 x = 1'b0; y = 1'b1; // 1
        #1 x = 1'b1; y = 1'b0; // 2
        #1 x = 1'b1; y = 1'b1; // 3
		end
endmodule // test_template
