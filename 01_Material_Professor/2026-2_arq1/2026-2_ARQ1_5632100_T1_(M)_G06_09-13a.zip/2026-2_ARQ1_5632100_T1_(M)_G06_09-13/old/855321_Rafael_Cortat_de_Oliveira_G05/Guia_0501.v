// -------------------------
// Guia_0501.v - GATES
// Nome: Rafael Cortat De Oliveira
// Matricula: 678019
// -------------------------

//(~a & b)

module original (output s, input a, input b);
    wire notA;
	not not1 (notA, a);
	and and1 (s, notA, b);
endmodule
/* TEST
// m a b s
// 0 0 0 0
// 1 0 1 1 <-
// 2 1 0 0
// 3 1 1 0
*/
//~(~(~(a & a) & b) & ~(~(a & a) & b))
module f51_nand (output s, input a, input b);
    wire not_a, nand1;
	nand notNand(not_a, a, a);
	nand nandAndPart1(nand1, not_a, b);
	nand nandAndPart2(s, nand1, nand1);
    
endmodule
/* TEST
// m a b s
// 0 0 0 0
// 1 0 1 1 <-
// 2 1 0 0
// 3 1 1 0
*/

// =======================================================
// TEST MODULE FOR MINTERMS 1-7
// =======================================================

module test_template;
    // ------------------------- definir dados
    reg x, y;
    wire out1, out2;

    original base (out1, x, y);
	f51_nand NANDtest (out2, x, y);

    // ------------------------- parte principal
    initial
    begin : main
        $display("Guia_0501 - GATES Template - Rafael Cortat De Oliveira - 999999");
        $display("Test module for Minterms");
        $display(" x y z | out");
        
        // projetar testes do modulo
        $monitor("%2b %2b| %3b | %3b", x, y, out1, out2);
        
        // Testing all minterms combinations
           x = 1'b0; y = 1'b0; // 0
        #1 x = 1'b0; y = 1'b1; // 1
        #1 x = 1'b1; y = 1'b0; // 2
        #1 x = 1'b1; y = 1'b1; // 3
		end
endmodule // test_template
