// -------------------------
// Guia_0502.v - GATES
// Nome: Rafael Cortat De Oliveira
// Matricula: 678019
// -------------------------



module original (output s, input a, input b);
    wire notB;
	not not1 (notB, b);
	or or1 (s, notB, a);
endmodule
/* TEST
// m a b s
// 0 0 0 1
// 1 0 1 0 
// 2 1 0 1
// 3 1 1 1
*/

module f52_nor(output s, input a, input b);
    wire not_b, nor1;
	nor NorNot1(not_b, b, b);
	nor Nor1(nor1, a, not_b);
	nor NorNot2(s, nor1, nor1);    
endmodule
/* TEST
// m a b s
// 0 0 0 1
// 1 0 1 0 
// 2 1 0 1
// 3 1 1 1
*/

// =======================================================
// TEST MODULE FOR MINTERMS 1-7
// =======================================================

module test_template;
    // ------------------------- definir dados
    reg x, y;
    wire out1, out2;

    original base (out1, x, y);
	f52_nor NORTest (out2, x, y);

    // ------------------------- parte principal
    initial
    begin : main
        $display("Guia_0501 - GATES Template - Rafael Cortat De Oliveira - 999999");
        $display("Test module for Minterms");
        $display(" x y z | out");
        
        // projetar testes do modulo
        $monitor("%2b %2b| %3b | %3b", x, y, out1, out2);
        
        // Testing all minterms combinations
           x = 1'b0; y = 1'b0; // 0
        #1 x = 1'b0; y = 1'b1; // 1
        #1 x = 1'b1; y = 1'b0; // 2
        #1 x = 1'b1; y = 1'b1; // 3
		end
endmodule // test_template
