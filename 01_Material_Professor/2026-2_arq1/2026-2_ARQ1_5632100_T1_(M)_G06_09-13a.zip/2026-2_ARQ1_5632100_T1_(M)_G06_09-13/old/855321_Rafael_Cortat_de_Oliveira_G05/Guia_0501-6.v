// Originalmente eu estava fazendo cada um em um arquivo separado, mas depois do 503 eu pedi um ia para juntar todos que tinha feito em um arquivo e continuei fazendo em so um arquivo para ficar mais simples para eu fazer. 
// -------------------------
// Guia_05 - GATES (0501 to 0506)
// Nome: Rafael Cortat De Oliveira
// Matricula: 678019
// -------------------------

// =======================================================
// Guia_0501
// =======================================================
// Expressão original: (~a & b)
module original_0501 (output s, input a, input b);
    wire notA;
    not not1 (notA, a);
    and and1 (s, notA, b);
endmodule

// Expressão original: (~a & b) usando apenas NAND
// Lógica extraída: ~(~(~(a & a) & b) & ~(~(a & a) & b))
module f51_nand (output s, input a, input b);
    wire not_a, nand1;
    nand notNand(not_a, a, a);
    nand nandAndPart1(nand1, not_a, b);
    nand nandAndPart2(s, nand1, nand1);
endmodule

// =======================================================
// Guia_0502
// =======================================================
// Expressão original: (a | ~b)
module original_0502 (output s, input a, input b);
    wire notB;
    not not1 (notB, b);
    or or1 (s, notB, a);
endmodule

// Expressão original: (a | ~b) usando apenas NOR
module f52_nor(output s, input a, input b);
    wire not_b, nor1;
    nor NorNot1(not_b, b, b);
    nor Nor1(nor1, a, not_b);
    nor NorNot2(s, nor1, nor1);    
endmodule

// =======================================================
// Guia_0503
// =======================================================
// Expressão original: ~(a | ~b)
module original_0503 (output s, input a, input b);
    wire notB, orOut1;
    not not1 (notB, b);
    or or1 (orOut1, a, notB);
    not notFinal(s, orOut1);
endmodule

// Módulo Auxiliar: Inversor (NOT) usando porta NAND
module not_nand (output s, input a);
    nand NAND1 (s, a, a);
endmodule

// Expressão original: ~(a | ~b) usando apenas NAND
module f53_nand (output s, input a, input b);
    wire notB, nandOrNot1, nandOrNot2, nandOrOut1;
    
    not_nand not1(notB, b);
    not_nand not2(nandOrNot1, a);
    not_nand not3(nandOrNot2, notB);
    nand nand1(nandOrOut1, nandOrNot1, nandOrNot2);
    not_nand not4(s, nandOrOut1);
endmodule

// =======================================================
// Guia_0504
// =======================================================
// Expressão original: ~(~a & b)
module original_0504 (output s, input a, input b);
    assign s = ~(~a & b);
endmodule

// Expressão original: ~(~a & b) usando apenas NOR
module f54_nor (output s, input a, input b);
    wire notFinal, notB;
	nor norNotB(notB, b, b);
	nor and1(notFinal, a, notB);
	nor norNotFinal(s, notFinal, notFinal);
endmodule

// =======================================================
// Guia_0505
// =======================================================
// Expressão original: ((a ^ b) = a xor b) - Disjunção exclusiva
module original_0505 (output s, input a, input b);
    assign s = (a ^ b);
endmodule

// Expressão original: (a ^ b) usando apenas NAND
module f55_nand (output s, input a, input b);
    wire gate1out, gate2out, gate3out;
	nand gate1(gate1out, a, b);
	nand gate2(gate2out, a, gate1out);
	nand gate3(gate3out, b, gate1out);
	nand gate4 (s, gate2out, gate3out);
endmodule

// =======================================================
// Guia_0506
// =======================================================
// Expressão original: (~(a ^ b) = a xnor b) - Negação da disjunção exclusiva
module original_0506 (output s, input a, input b);
    assign s = ~(a ^ b);
endmodule

// Expressão original: ~(a ^ b) usando apenas NOR
module f56_nor (output s, input a, input b);
    wire gate1out, gate2out, gate3out;
	nor gate1(gate1out, a, b);
	nor gate2(gate2out, a, gate1out);
	nor gate3(gate3out, b, gate1out);
	nor gate4 (s, gate2out, gate3out);
endmodule


// =======================================================
// TEST MODULE FOR MINTERMS (0501 - 0506)
// =======================================================
module test_all;
    // ------------------------- definir dados
    reg x, y;
    
    // Outputs for 0501
    wire out1_0501, out2_0501;
    // Outputs for 0502
    wire out1_0502, out2_0502;
    // Outputs for 0503
    wire out1_0503, out2_0503;
    // Outputs for 0504
    wire out1_0504, out2_0504;
    // Outputs for 0505
    wire out1_0505, out2_0505;
    // Outputs for 0506
    wire out1_0506, out2_0506;

    // Instantiate 0501
    original_0501 base_0501 (out1_0501, x, y);
    f51_nand test_0501 (out2_0501, x, y);

    // Instantiate 0502
    original_0502 base_0502 (out1_0502, x, y);
    f52_nor test_0502 (out2_0502, x, y);

    // Instantiate 0503
    original_0503 base_0503 (out1_0503, x, y);
    f53_nand test_0503 (out2_0503, x, y);

    // Instantiate 0504
    original_0504 base_0504 (out1_0504, x, y);
    f54_nor test_0504 (out2_0504, x, y);

    // Instantiate 0505
    original_0505 base_0505 (out1_0505, x, y);
    f55_nand test_0505 (out2_0505, x, y);

    // Instantiate 0506
    original_0506 base_0506 (out1_0506, x, y);
    f56_nor test_0506 (out2_0506, x, y);

    // ------------------------- parte principal
    initial
    begin : main
        $display("Guia_05 - GATES - Rafael Cortat De Oliveira - 678019");
        $display("Test module for Guia 0501 to 0506");
        $display(" x y | 501(o t) | 502(o t) | 503(o t) | 504(o t) | 505(o t) | 506(o t)");
        
        $monitor("%2b %2b |   %1b %1b    |   %1b %1b    |   %1b %1b    |   %1b %1b    |   %1b %1b    |   %1b %1b", 
                 x, y, 
                 out1_0501, out2_0501, 
                 out1_0502, out2_0502, 
                 out1_0503, out2_0503, 
                 out1_0504, out2_0504, 
                 out1_0505, out2_0505, 
                 out1_0506, out2_0506);
        
        // Testing all minterms combinations
           x = 1'b0; y = 1'b0; // 0
        #1 x = 1'b0; y = 1'b1; // 1
        #1 x = 1'b1; y = 1'b0; // 2
        #1 x = 1'b1; y = 1'b1; // 3
    end
endmodule // test_all