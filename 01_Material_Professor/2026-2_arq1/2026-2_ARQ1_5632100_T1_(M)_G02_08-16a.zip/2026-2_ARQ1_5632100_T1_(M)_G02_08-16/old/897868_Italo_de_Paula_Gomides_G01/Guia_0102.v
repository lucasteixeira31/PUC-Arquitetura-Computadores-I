/*
 Guia_0102.v
 897868 - Italo de Paula Gomides
 Conversao binario para decimal
*/
module Guia_0102;
// define data
 integer x = 0; // decimal
 reg [7:0] b = 8'b10011; // binary (trocar para os outros valores da lista e repetir o teste)

// actions
 initial
 begin : main
 $display ( "Guia_0102 - Tests" );
 $display ( "x = %d" , x );
 $display ( "b = %8b", b );
 x = b;
 $display ( "b = %d", x );
 end // main
endmodule // Guia_0102

/*
 // colocar aqui as saidas obtidas e comentarios/duvidas
*/
