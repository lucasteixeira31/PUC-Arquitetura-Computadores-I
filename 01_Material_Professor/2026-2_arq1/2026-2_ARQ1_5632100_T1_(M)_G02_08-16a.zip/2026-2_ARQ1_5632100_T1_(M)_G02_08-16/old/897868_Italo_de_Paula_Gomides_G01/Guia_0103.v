/*
 Guia_0103.v
 897868 - Italo de Paula Gomides
 Conversao decimal para binario / octal / hexadecimal
*/
module Guia_0103;
// define data
 integer x = 45; // decimal (trocar para 67, 79, 153, 741 e repetir o teste)
 reg [9:0] b = 0; // binary

// actions
 initial
 begin : main
 $display ( "Guia_0103 - Tests" );
 $display ( "x = %d" , x );
 $display ( "b = %10b", b );
 b = x;
 $display ( "b = %B (2) = %o (8) = %x (16) = %X (16)", b, b, b, b );
 end // main
endmodule // Guia_0103

/*
 // colocar aqui as saidas obtidas e comentarios/duvidas
*/
