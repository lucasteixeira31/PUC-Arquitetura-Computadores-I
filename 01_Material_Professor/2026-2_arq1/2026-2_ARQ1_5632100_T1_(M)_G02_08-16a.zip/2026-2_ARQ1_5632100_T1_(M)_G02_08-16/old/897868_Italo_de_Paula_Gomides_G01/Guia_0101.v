/*
 Guia_0101.v
 897868 - Italo de Paula Gomides
 Conversao decimal para binario
*/
module Guia_0101;
// define data
 integer x = 29; // decimal (trocar para 53, 761, 213, 365 e repetir o teste)
 reg [9:0] b = 0; // binary (bits suficientes para os maiores valores)

// actions
 initial
 begin : main
 $display ( "Guia_0101 - Tests" );
 $display ( "x = %d" , x );
 $display ( "b = %10b", b );
 b = x;
 $display ( "b = %10b", b );
 end // main
endmodule // Guia_0101

/*
 // colocar aqui as saidas obtidas e comentarios/duvidas
*/
