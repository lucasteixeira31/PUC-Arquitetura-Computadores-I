/*
Guia_0102.v
678019 - Rafael Cortat De Oliveira
*/
module Guia_0102;
integer base10 = 0; 

reg [16:0] base2 [0:4]; 

// actions
initial
begin : main
    $display ( "Guia_0102 - Tests" );

	base2[0] = 8'b10011;
    base2[1] = 8'b10100;
    base2[2] = 8'b10111;
    base2[3] = 8'b101111;
    base2[4] = 8'b111100;
    for (int i = 0; i < 5; i++) begin
        $display ( "base2 = %16b" , base2[i]);
        base10 = base2[i]; 
        $display ( "base10 = %d", base10);
    end
end // main
endmodule // Guia_0102