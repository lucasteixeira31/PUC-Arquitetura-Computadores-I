/*
Guia_0103.v
678019 - Rafael Cortat De Oliveira
*/
module Guia_0103;
integer base10 [0:4]; 

reg [16:0] baseNew; 
// actions
initial
begin : main
    $display ( "Guia_0103 - Tests" );

	base10[0] = 45;
    base10[1] = 67;
    base10[2] = 79;
    base10[3] = 153;
    base10[4] = 741;
    for (int i = 0; i < 5; i++) begin
        $display ( "base10 = %d" , base10[i]);
        baseNew = base10[i];
        $display ( "b = %B (2) = %o (8) = %x (16) = %X (16)", baseNew, baseNew, baseNew, baseNew);
    end
end // main
endmodule // Guia_0103