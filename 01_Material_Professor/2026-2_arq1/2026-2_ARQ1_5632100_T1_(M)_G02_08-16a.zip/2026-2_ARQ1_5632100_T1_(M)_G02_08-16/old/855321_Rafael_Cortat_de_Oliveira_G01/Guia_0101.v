/*
Guia_0101.v
678019 - Rafael Cortat De Oliveira
*/
module Guia_0101;
reg [16:0] b = 0; 

integer base10 [0:4]; 

// actions
initial
begin : main
    $display ( "Guia_0101 - Tests" );

base10[0] = 29;
    base10[1] = 53;
    base10[2] = 761;
    base10[3] = 213;
    base10[4] = 365;
    for (int i = 0; i < 5; i++) begin
        $display ( "x = %d" , base10[i]);
        b = base10[i]; 
        $display ( "b = %16b", b );
    end
end // main
endmodule // Guia_0101