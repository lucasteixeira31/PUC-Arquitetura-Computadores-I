/*
Guia_0104.v
678019 - Rafael Cortat De Oliveira
*/
module Guia_0104;
reg [16:0] base2 [0:4];  
// actions
initial
begin : main
    $display ( "Guia_0104 - Tests" );

	base2[0] = 8'b10011;
    base2[1] = 8'b11001;
    base2[2] = 8'b100011;
    base2[3] = 8'b101001;
    base2[4] = 8'b110011;
    for (int i = 0; i < 5; i++) begin
           $display ( "base2 = %d" , base2[i]);
        $display ( "b = [%4b] [%4b] = %x %x", base2[i][7:4], base2[i][3:0], base2[i][7:4], base2[i][3:0] );
        
        $display ( "base4 = %0d%0d%0d%0d", base2[i][7:6], base2[i][5:4], base2[i][3:2], base2[i][1:0] );
        
        $display ( "base8 = %o", base2[i] );
    end
end // main
endmodule // Guia_0104