Guia_01 - Observacoes gerais
897868 - Italo de Paula Gomides

Pasta de entrega: 897868-Italo_de_Paula_Gomides

Estrutura da entrega:
- Guia_01.txt      -> respostas manuais (itens "a" de cada questao) com passos detalhados
- Guia_0101.v ... Guia_0105.v -> codigo fonte Verilog de cada questao, com modulo de testes
  (saidas obtidas coladas ao final de cada arquivo, em comentario)
- IA_uso.txt       -> registro do uso de ferramenta de IA (prompt e finalidade)
- README.txt       -> este arquivo

Para compilar (Windows), dentro desta pasta:
 iverilog -o Guia_0101.vvp Guia_0101.v
 vvp Guia_0101.vvp

Repetir trocando o numero do arquivo (0102, 0103, 0104, 0105).

IMPORTANTE: antes de compactar para entrega, apagar os arquivos .vvp
gerados pela compilacao (sao arquivos intermediarios/executaveis e
nao devem ser entregues, conforme instrucoes da disciplina).

Observacoes / duvidas:
(preencher conforme necessario)
