/*
Guia_0201.v
678019 - Rafael Cortat De Oliveira
*/
module Guia_0201;
// define data
real x;
real power2;
integer y;
integer i;
reg [7:0] base2whole[0:4]; 
reg [7:0] base2frac[0:4]; 

// actions
initial
begin : main
base2whole[0] = 8'd0; base2frac[0] = 8'b00101000;
base2whole[1] = 8'd0; base2frac[1] = 8'b01011000;
base2whole[2] = 8'd0; base2frac[2] = 8'b10111000;
base2whole[3] = 8'd1; base2frac[3] = 8'b01101000;
base2whole[4] = 8'd2; base2frac[4] = 8'b11001000;

$display ( "Guia_0201 - Tests" );

for (i = 0; i < 5; i = i + 1) begin
x = base2whole[i];
y = 7;
power2 = 1.0;

$display ( "x = %f" , x );
$display ( "base2 = %0d.%8b", base2whole[i], base2frac[i]);

while ( y >= 0 )
begin
power2 = power2 / 2.0;
if ( base2frac[i][y] == 1 )
begin
x = x + power2;
end
// $display ( "x = %f", x ); 
y = y - 1;
end 

$display ( "Final number = %f\n", x );

end // end while
end // main
endmodule // Guia_0201