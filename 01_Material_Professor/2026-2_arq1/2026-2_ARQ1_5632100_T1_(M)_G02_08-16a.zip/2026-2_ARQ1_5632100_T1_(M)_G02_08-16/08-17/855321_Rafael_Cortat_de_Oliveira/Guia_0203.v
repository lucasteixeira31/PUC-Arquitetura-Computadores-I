/*
Guia_0203.v
678019 - Rafael Cortat De Oliveira
*/
module Guia_0203;
// define data
real x [0:4]; // decimal
reg [7:0] a [0:4]; // integer part in binary
reg [7:0] b [0:4]; // fractional part in binary
// actions
initial
begin : main
$display ( "Guia_0203 - Tests" );
// Initialize arrays with the given values
// a.) 0,001001(2)
x[0] = 0.140625;
a[0] = 8'b0000_0000;
b[0] = 8'b0010_0100; // padded to 8 bits
// b.) 0,100001(2)
x[1] = 0.515625;
a[1] = 8'b0000_0000;
b[1] = 8'b1000_0100; // padded to 8 bits
// c.) 0,101101(2)
x[2] = 0.703125;
a[2] = 8'b0000_0000;
b[2] = 8'b1011_0100; // padded to 8 bits
// d.) 1,110011(2)
x[3] = 1.796875;
a[3] = 8'b0000_0001;
b[3] = 8'b1100_1100; // padded to 8 bits
// e.) 1101,0101(2)
x[4] = 13.3125;
a[4] = 8'b0000_1101;
b[4] = 8'b0101_0000; // padded to 8 bits
for (int i = 0; i < 5; i++) begin

    
    $display ( "binary = %0b.%8b (2)", a[i], b[i] );
    
    $display ( "base 4 = %0d%0d%0d%0d.%0d%0d%0d%0d (4)", 
               a[i][7:6], a[i][5:4], a[i][3:2], a[i][1:0], 
               b[i][7:6], b[i][5:4], b[i][3:2], b[i][1:0] );
               
    // Base 8
    $display ( "base 8 = %o.%o%o%o (8)", a[i], b[i][7:5], b[i][4:2], b[i][1:0] );
    
    // Base 16
    $display ( "base 16 = %x.%x%x (16)", a[i], b[i][7:4], b[i][3:0] );
end
end // main
endmodule // Guia_0203