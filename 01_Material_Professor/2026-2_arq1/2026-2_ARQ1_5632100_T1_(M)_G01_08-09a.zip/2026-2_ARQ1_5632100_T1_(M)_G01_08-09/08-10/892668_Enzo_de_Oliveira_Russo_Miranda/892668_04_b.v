/*
Guia_0104.v
892668 - Enzo de Oliveira Russo Miranda
*/
module Guia_0104;
// define data
integer x = 0; // decimal
reg [7:0] b = 8'b101001; // binary
// actions
initial
begin : main
x = b;
$display ( "Guia_0104 - Tests" );
$display ( "x = %d" , x );
$display ( "b = %8b", b );
$display ( "b = %B (2) = %o (8) = %d%d%d%d (4) = %x (16) = %X (16)", b, b, b[7:6], b[5:4], b[3:2], b[1:0], b, b ); // Adicionei par abase quaternária agrupando os bits de dois em dois
end // main
endmodule // Guia_0104