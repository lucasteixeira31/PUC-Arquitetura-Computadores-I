/*
 Guia_0101.v
 801169 - Leonardo Amaral
*/

module Guia_0101;

// define data
integer x;
reg [15:0] b;

// actions
initial
begin : main

   $display("Guia_0101 - Conversao Decimal -> Binario\n");

   x = 29;
   b = x;
   $display("29  = %b", b);

   x = 53;
   b = x;
   $display("53  = %b", b);

   x = 761;
   b = x;
   $display("761 = %b", b);

   x = 213;
   b = x;
   $display("213 = %b", b);

   x = 365;
   b = x;
   $display("365 = %b", b);

end
/*
Obs: Foi utilizado reg [15:0] 
porque o número 761 necessita de 10 bits para ser representado
em binário, e 8 bits não seriam suficientes.
*/
endmodule