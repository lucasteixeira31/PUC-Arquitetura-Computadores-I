// Guia 0507
// Nome: NATHAN BARROS
// Matricula: 1593351

module f7 ( output s,
input a,
input b );

wire n1, n2, n3, xor_ab;

nand NAND1 ( n1, a, b );
nand NAND2 ( n2, a, n1 );
nand NAND3 ( n3, b, n1 );
nand NAND4 ( xor_ab, n2, n3 );
nand NAND5 ( s, xor_ab, xor_ab );

endmodule

module test_f7;
reg x, y;
wire z;

f7 modulo ( z, x, y );

initial begin
$display("Guia_0507 - NATHAN BARROS - 1593351");
$display(" a  b  s");
$monitor("%2b %2b %2b", x, y, z);

x = 1'b0; y = 1'b0;
#1 x = 1'b0; y = 1'b1;
#1 x = 1'b1; y = 1'b0;
#1 x = 1'b1; y = 1'b1;
end
endmodule
