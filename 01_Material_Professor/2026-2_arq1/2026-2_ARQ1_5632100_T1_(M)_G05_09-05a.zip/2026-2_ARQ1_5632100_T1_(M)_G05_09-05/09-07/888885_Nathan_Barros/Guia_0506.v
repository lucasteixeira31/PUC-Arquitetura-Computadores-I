// Guia 0506
// Nome: NATHAN BARROS
// Matricula: 1593351

module f6 ( output s,
input a,
input b );

wire n1, n2, n3;

nor NOR1 ( n1, a, b );
nor NOR2 ( n2, a, n1 );
nor NOR3 ( n3, b, n1 );
nor NOR4 ( s, n2, n3 );

endmodule

module test_f6;
reg x, y;
wire z;

f6 modulo ( z, x, y );

initial begin
$display("Guia_0506 - NATHAN BARROS - 1593351");
$display(" a  b  s");
$monitor("%2b %2b %2b", x, y, z);

x = 1'b0; y = 1'b0;
#1 x = 1'b0; y = 1'b1;
#1 x = 1'b1; y = 1'b0;
#1 x = 1'b1; y = 1'b1;
end
endmodule
