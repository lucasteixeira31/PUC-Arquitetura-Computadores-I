// Guia 0503
// Nome: NATHAN BARROS
// Matricula: 1593351

module f3 ( output s,
input a,
input b );

wire not_b;
nand NAND1 ( not_b, b, b );

wire not_a, temp;
nand NAND2 ( not_a, a, a );
nand NAND3 ( temp, not_a, b );
nand NAND4 ( s, temp, temp );

endmodule

module test_f3;
reg x, y;
wire z;

f3 modulo ( z, x, y );

initial begin
$display("Guia_0503 - NATHAN BARROS - 1593351");
$display(" a  b  s");
$monitor("%2b %2b %2b", x, y, z);

x = 1'b0; y = 1'b0;
#1 x = 1'b0; y = 1'b1;
#1 x = 1'b1; y = 1'b0;
#1 x = 1'b1; y = 1'b1;
end
endmodule
