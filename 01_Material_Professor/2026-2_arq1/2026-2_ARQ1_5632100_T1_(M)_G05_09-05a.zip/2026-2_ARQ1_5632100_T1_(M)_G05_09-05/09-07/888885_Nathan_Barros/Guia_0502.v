// Guia 0502
// Nome: NATHAN BARROS
// Matricula: 1593351

module f2 ( output s,
input a,
input b );

wire not_b;
nor NOR1 ( not_b, b, b );

wire temp;
nor NOR2 ( temp, a, not_b );
nor NOR3 ( s, temp, temp );

endmodule

module test_f2;
reg x, y;
wire z;

f2 modulo ( z, x, y );

initial begin
$display("Guia_0502 - NATHAN BARROS - 1593351");
$display(" a  b  s");
$monitor("%2b %2b %2b", x, y, z);

x = 1'b0; y = 1'b0;
#1 x = 1'b0; y = 1'b1;
#1 x = 1'b1; y = 1'b0;
#1 x = 1'b1; y = 1'b1;
end
endmodule
