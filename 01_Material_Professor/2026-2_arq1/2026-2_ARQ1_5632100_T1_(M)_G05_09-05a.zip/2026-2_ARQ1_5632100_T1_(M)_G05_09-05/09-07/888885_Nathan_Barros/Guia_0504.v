// Guia 0504
// Nome: NATHAN BARROS
// Matricula: 1593351

module f4 ( output s,
input a,
input b );

wire not_a;
nor NOR1 ( not_a, a, a );

wire not_b, temp;
nor NOR2 ( not_b, b, b );
nor NOR3 ( temp, not_a, not_b );
nor NOR4 ( s, temp, temp );

endmodule

module test_f4;
reg x, y;
wire z;

f4 modulo ( z, x, y );

initial begin
$display("Guia_0504 - NATHAN BARROS - 1593351");
$display(" a  b  s");
$monitor("%2b %2b %2b", x, y, z);

x = 1'b0; y = 1'b0;
#1 x = 1'b0; y = 1'b1;
#1 x = 1'b1; y = 1'b0;
#1 x = 1'b1; y = 1'b1;
end
endmodule
