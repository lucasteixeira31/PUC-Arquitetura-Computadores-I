// Guia 5
// Nome: NATHAN BARROS
// Matricula: 1593351

module f1 ( output s,
input a,
input b );

wire not_a;
nand NAND1 ( not_a, a, a );

wire temp;
nand NAND2 ( temp, not_a, b );
nand NAND3 ( s, temp, temp );

endmodule

module test_f1;
reg x, y;
wire z;

f1 modulo ( z, x, y );

initial begin
$display("Guia_0501 - NATHAN BARROS - 1593351");
$display(" a  b  s");
$monitor("%2b %2b %2b", x, y, z);

x = 1'b0; y = 1'b0;
#1 x = 1'b0; y = 1'b1;
#1 x = 1'b1; y = 1'b0;
#1 x = 1'b1; y = 1'b1;
end
endmodule
