// Guia 0508
// Nome: NATHAN BARROS
// Matricula: 1593351

module f8 ( output s,
input a,
input b );

wire not_a, not_b, and_ab;

nor NOR1 ( not_a, a, a );
nor NOR2 ( not_b, b, b );
nor NOR3 ( and_ab, not_a, not_b );
nor NOR4 ( s, and_ab, and_ab );

endmodule

module test_f8;
reg x, y;
wire z;

f8 modulo ( z, x, y );

initial begin
$display("Guia_0508 - NATHAN BARROS - 1593351");
$display(" a  b  s");
$monitor("%2b %2b %2b", x, y, z);

x = 1'b0; y = 1'b0;
#1 x = 1'b0; y = 1'b1;
#1 x = 1'b1; y = 1'b0;
#1 x = 1'b1; y = 1'b1;
end
endmodule
