/*
 Guia_0504.v
 801169 - Leonardo Amaral

 Expressão:
 S = ~(~a & b)

 Equivalente:
 S = a | ~b

 Implementação utilizando somente portas NOR.
*/

module Guia_0504(
    output s,
    input a,
    input b
);

wire nb;
wire temp;

// NOR usada como NOT: ~b
nor n1(nb, b, b);

// NOR entre a e ~b
nor n2(temp, a, nb);

// NOR usada como NOT para obter OR
nor n3(s, temp, temp);

endmodule