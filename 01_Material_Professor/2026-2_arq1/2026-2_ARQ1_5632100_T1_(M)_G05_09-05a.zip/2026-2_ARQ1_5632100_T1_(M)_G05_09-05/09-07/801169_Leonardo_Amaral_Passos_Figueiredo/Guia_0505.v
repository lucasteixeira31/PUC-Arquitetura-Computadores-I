/*
 Guia_0505.v
 801169 - Leonardo Amaral

 Implementação de uma disjunção exclusiva (XOR)
 utilizando somente portas NAND.

 Expressão:
 S = a ^ b
*/

module Guia_0505(
    output s,
    input a,
    input b
);

wire t1;
wire t2;
wire t3;

// Primeira NAND
nand n1(t1, a, b);

// Segunda NAND
nand n2(t2, a, t1);

// Terceira NAND
nand n3(t3, b, t1);

// Quarta NAND - saída XOR
nand n4(s, t2, t3);

endmodule