/*
 Guia_0502.v
 801169 - Leonardo Amaral

 Expressão:
 S = (a | ~b)

 Implementação utilizando somente portas NOR.
*/

module Guia_0502(
    output s,
    input a,
    input b
);

wire nb;
wire temp;

//NOT b utilizando NOR
nor n1(nb, b, b);

//NOR entre a e ~b
nor n2(temp, a, nb);

//Inversão para obter OR
nor n3(s, temp, temp);

endmodule