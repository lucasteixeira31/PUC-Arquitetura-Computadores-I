/*
 Guia_0501.v
 801169 - Leonardo Amaral

 Expressão:
 S = (~a & b)

 Implementação utilizando somente portas NAND.
*/

module Guia_0501(
    output s,
    input a,
    input b
);

wire na;
wire temp;

//NOT a utilizando NAND
nand n1(na, a, a);

//NAND entre ~a e b
nand n2(temp, na, b);

//NAND para transformar NAND em AND
nand n3(s, temp, temp);

endmodule