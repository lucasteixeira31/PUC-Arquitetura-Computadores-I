/*
 Guia_0503.v
 801169 - Leonardo Amaral

 Expressão:
 S = ~(a | ~b)

 Equivalente:
 S = ~a & b

 Implementação utilizando somente portas NAND.
*/

module Guia_0503(
    output s,
    input a,
    input b
);

wire na;
wire temp;

//NAND usada como NOT: ~a
nand n1(na, a, a);

//NAND entre ~a e b
nand n2(temp, na, b);

//NAND usada como NOT para obter ~a & b
nand n3(s, temp, temp);

endmodule