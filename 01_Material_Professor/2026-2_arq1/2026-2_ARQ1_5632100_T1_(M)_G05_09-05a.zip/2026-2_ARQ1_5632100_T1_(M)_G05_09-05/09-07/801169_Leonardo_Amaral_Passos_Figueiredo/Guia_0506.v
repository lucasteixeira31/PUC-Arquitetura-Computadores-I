/*
 Guia_0506.v
 801169 - Leonardo Amaral

 Implementação da negação da disjunção exclusiva (XNOR)
 utilizando somente portas NOR.

 Expressão:
 S = ~(a ^ b)
*/

module Guia_0506(
    output s,
    input a,
    input b
);

wire t1;
wire t2;
wire t3;

// Primeira NOR
nor n1(t1, a, b);

// Segunda NOR
nor n2(t2, a, t1);

// Terceira NOR
nor n3(t3, b, t1);

// Quarta NOR - saída XNOR
nor n4(s, t2, t3);

endmodule