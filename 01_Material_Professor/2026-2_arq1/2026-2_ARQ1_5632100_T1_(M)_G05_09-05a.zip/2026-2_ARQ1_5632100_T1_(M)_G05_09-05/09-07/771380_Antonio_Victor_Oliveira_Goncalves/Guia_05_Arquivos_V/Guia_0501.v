// Nome: Antônio Victor Oliveira Goncalves
// Matricula: 771380
// --------------------------------------------------

// Questao 01
// Funcao: s = (~a & b)
// Implementacao usando apenas portas NAND

module guia_0501 (
    output s,
    input a,
    input b
);

    wire not_a;
    wire temp;

    nand NAND1 (not_a, a, a);
    nand NAND2 (temp, not_a, b);
    nand NAND3 (s, temp, temp);

endmodule

module test_guia_0501;
    reg a, b;
    wire s;

    guia_0501 modulo (s, a, b);

    initial begin
        $display("Guia_0501 - Antonio Victor Oliveira Goncalves - 771380");
        $display(" a b | s");
        $monitor(" %b %b | %b", a, b, s);

        a = 0; b = 0;
        #1 a = 0; b = 1;
        #1 a = 1; b = 0;
        #1 a = 1; b = 1;
    end
endmodule
