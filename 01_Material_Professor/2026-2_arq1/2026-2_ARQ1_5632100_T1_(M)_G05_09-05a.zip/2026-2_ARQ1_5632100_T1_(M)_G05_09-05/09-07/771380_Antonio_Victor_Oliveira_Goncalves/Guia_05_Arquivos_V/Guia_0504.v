// Nome: Antônio Victor Oliveira Goncalves
// Matricula: 771380
// --------------------------------------------------

// Questao 04
// Funcao: s = ~(~a & b)
// Pela algebra booleana: ~(~a & b) = (a | ~b)
// Implementacao usando apenas portas NOR

module guia_0504 (
    output s,
    input a,
    input b
);

    wire not_b;
    wire temp;

    nor NOR1 (not_b, b, b);
    nor NOR2 (temp, a, not_b);
    nor NOR3 (s, temp, temp);

endmodule

module test_guia_0504;
    reg a, b;
    wire s;

    guia_0504 modulo (s, a, b);

    initial begin
        $display("Guia_0504 - Antônio Victor Oliveira Goncalves - 771380");
        $display(" a b | s");
        $monitor(" %b %b | %b", a, b, s);

        a = 0; b = 0;
        #1 a = 0; b = 1;
        #1 a = 1; b = 0;
        #1 a = 1; b = 1;
    end
endmodule
