// Nome: Antônio Victor Oliveira Goncalves
// Matricula: 771380
// --------------------------------------------------

// Questao 06
// Funcao: s = ~(a ^ b)
// Implementacao XNOR usando apenas portas NOR

module guia_0506 (
    output s,
    input a,
    input b
);

    wire n1;
    wire n2;
    wire n3;

    nor NOR1 (n1, a, b);
    nor NOR2 (n2, a, n1);
    nor NOR3 (n3, b, n1);
    nor NOR4 (s, n2, n3);

endmodule

module test_guia_0506;
    reg a, b;
    wire s;

    guia_0506 modulo (s, a, b);

    initial begin
        $display("Guia_0506 - Antônio Victor Oliveira Goncalves - 771380");
        $display(" a b | s");
        $monitor(" %b %b | %b", a, b, s);

        a = 0; b = 0;
        #1 a = 0; b = 1;
        #1 a = 1; b = 0;
        #1 a = 1; b = 1;
    end
endmodule
