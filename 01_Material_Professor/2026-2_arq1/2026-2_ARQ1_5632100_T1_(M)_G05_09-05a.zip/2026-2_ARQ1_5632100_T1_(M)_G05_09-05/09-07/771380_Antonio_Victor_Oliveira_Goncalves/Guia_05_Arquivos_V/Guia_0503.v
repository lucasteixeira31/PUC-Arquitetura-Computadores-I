// Nome: Antônio Victor Oliveira Goncalves
// Matricula: 771380
// --------------------------------------------------

// Questao 03
// Funcao: s = ~(a | ~b)
// Pela algebra booleana: ~(a | ~b) = (~a & b)
// Implementacao usando apenas portas NAND

module guia_0503 (
    output s,
    input a,
    input b
);

    wire not_a;
    wire temp;

    nand NAND1 (not_a, a, a);
    nand NAND2 (temp, not_a, b);
    nand NAND3 (s, temp, temp);

endmodule

module test_guia_0503;
    reg a, b;
    wire s;

    guia_0503 modulo (s, a, b);

    initial begin
        $display("Guia_0503 - Antônio Victor Oliveira Goncalves - 771380");
        $display(" a b | s");
        $monitor(" %b %b | %b", a, b, s);

        a = 0; b = 0;
        #1 a = 0; b = 1;
        #1 a = 1; b = 0;
        #1 a = 1; b = 1;
    end
endmodule
