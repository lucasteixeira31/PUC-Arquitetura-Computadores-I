// Nome: Antônio Victor Oliveira Goncalves
// Matricula: 771380
// --------------------------------------------------

// Questao 02
// Funcao: s = (a | ~b)
// Implementacao usando apenas portas NOR

module guia_0502 (
    output s,
    input a,
    input b
);

    wire not_b;
    wire temp;

    nor NOR1 (not_b, b, b);
    nor NOR2 (temp, a, not_b);
    nor NOR3 (s, temp, temp);

endmodule

module test_guia_0502;
    reg a, b;
    wire s;

    guia_0502 modulo (s, a, b);

    initial begin
        $display("Guia_0502 - Antonio Victor Oliveira Goncalves - 771380");
        $display(" a b | s");
        $monitor(" %b %b | %b", a, b, s);

        a = 0; b = 0;
        #1 a = 0; b = 1;
        #1 a = 1; b = 0;
        #1 a = 1; b = 1;
    end
endmodule
