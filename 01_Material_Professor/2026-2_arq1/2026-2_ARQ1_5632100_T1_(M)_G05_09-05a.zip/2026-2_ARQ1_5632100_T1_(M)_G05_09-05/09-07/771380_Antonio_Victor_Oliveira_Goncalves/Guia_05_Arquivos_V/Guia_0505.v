// Nome: Antônio Victor Oliveira Goncalves
// Matricula: 771380
// --------------------------------------------------

// Questao 05
// Funcao: s = (a ^ b)
// Implementacao XOR usando apenas portas NAND

module guia_0505 (
    output s,
    input a,
    input b
);

    wire n1;
    wire n2;
    wire n3;

    nand NAND1 (n1, a, b);
    nand NAND2 (n2, a, n1);
    nand NAND3 (n3, b, n1);
    nand NAND4 (s, n2, n3);

endmodule

module test_guia_0505;
    reg a, b;
    wire s;

    guia_0505 modulo (s, a, b);

    initial begin
        $display("Guia_0505 - Antônio Victor Oliveira Goncalves - 771380");
        $display(" a b | s");
        $monitor(" %b %b | %b", a, b, s);

        a = 0; b = 0;
        #1 a = 0; b = 1;
        #1 a = 1; b = 0;
        #1 a = 1; b = 1;
    end
endmodule
